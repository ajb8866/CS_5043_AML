import tensorflow as tf
from tensorflow.keras.models import Model
from tensorflow.keras.layers import Input, Flatten, Dense, Concatenate, Conv2D, LeakyReLU, Dropout, SpatialDropout2D, MaxPooling2D
from tensorflow.keras.optimizers import Adam
from  unet_model import *
from network_support import *

def create_discriminator(image_size, num_classes, channels,p_dropout,p_spatial,lrate,batch_norm, alpha):
    """
    Constructs a discriminator model for a GAN, which includes image and semantic label inputs.
    
    :param image_size: Size (height and width) of the input image.
    :param num_classes: Number of classes for semantic segmentation, indicating the depth of the label input.
    :param channels: Number of channels in the input images (e.g., 3 for RGB images).
    :param p_dropout: Probability of dropout in each convolutional block.
    :param p_spatial: Probability of spatial dropout in each convolutional block.
    :param lrate: Learning rate for the optimizer.
    :param batch_norm: Whether to include batch normalization layers.
    :param alpha: Slope coefficient for the LeakyReLU activation function.
    """
    image_input = Input(shape=(image_size, image_size, channels), name='image_input')
    label_input = Input(shape=(image_size, image_size, num_classes), name='label_input')
    combined_input = Concatenate()([image_input, label_input])
    
    
    # First set of convolutional layers
    x = Conv2D(64, (3, 3), strides=(2, 2), padding='same')(combined_input)
    x = LeakyReLU(alpha=alpha)(x)
    if batch_norm:
        x = BatchNormalization()(x)
    if p_spatial > 0:
        x = SpatialDropout2D(p_spatial)(x)  
    
     # Second set of convolutional layers
    x = Conv2D(96, (3, 3), strides=(2, 2), padding='same')(combined_input)
    x = LeakyReLU(alpha=alpha)(x)
    if batch_norm:
        x = BatchNormalization()(x)
    if p_spatial > 0:
        x = SpatialDropout2D(p_spatial)(x)
     
    # Third set of convolutional layers
    x = Conv2D(128, (3, 3), strides=(2, 2), padding='same')(x)
    x = LeakyReLU(alpha=alpha)(x)
    if batch_norm:
        x = BatchNormalization()(x)
    if p_spatial > 0:
        x = SpatialDropout2D(p_spatial)(x)  
    x = MaxPooling2D((2, 2), strides=(2, 2))(x)

    
    # Flatten and Dense layers
    x = Flatten()(x)
    x = LeakyReLU(alpha=alpha)(x)
    if p_dropout > 0:
        x = Dropout(p_dropout)(x)
    x = Dense(1, activation='sigmoid')(x)

    # Compile the model
    model = Model(inputs=[image_input, label_input], outputs=x, name='discriminator')
    optimizer = Adam(learning_rate=lrate, beta_1=0.5)
    model.compile(loss='binary_crossentropy', optimizer=optimizer, metrics=['accuracy'])
    
    return model

def create_gan(generator, discriminator, lrate):
    """
    Connects a generator and a discriminator to form a GAN (Generative Adversarial Network).
    
    :param generator: The generator model that produces images.
    :param discriminator: The discriminator model that classifies images.
    :param lrate: Learning rate for the Adam optimizer used in compiling the GAN.
    """
    

    discriminator.trainable = False
    gen_inputs = generator.inputs  # Inputs to the generator: semantic labels and noise tensors
    gen_output = generator.output  # The generated image
    gan_output = discriminator([gen_output] + [gen_inputs[0]])  # Combine generated image with semantic label input
    gan = Model(inputs=gen_inputs, outputs=gan_output, name='gan')
    optimizer = Adam(learning_rate=lrate, beta_1=0.5, beta_2=0.999)
    gan.compile(optimizer=optimizer, loss='binary_crossentropy')

    return gan

def create_GAN_model(image_size, num_classes, channels, conv_layers, kernel_size, padding, p_dropout, p_spatial,lrate, batch_norm,activation_conv, alpha):
    """
    Initializes the discriminator, generator, and GAN models based on provided specifications and returns them.
    
    :param image_size: Size of the images (height and width).
    :param num_classes: Number of classes used in the semantic segmentation (depth of label inputs).
    :param channels: Number of channels in the input image (e.g., RGB = 3).
    :param conv_layers: Specifications of convolutional layers used in the generator.
    :param kernel_size: Size of the kernels used in convolutional layers.
    :param padding: Padding strategy ('same' or 'valid').
    :param p_dropout: Probability of dropout in each convolutional block.
    :param p_spatial: Probability of spatial dropout in each convolutional block.
    :param lrate: Learning rate for the optimizer.
    :param batch_norm: Whether to include batch normalization layers.
    :param activation_conv: Activation function used in the convolutional layers.
    :param alpha: Slope coefficient for the LeakyReLU activation in the discriminator.
    """
    generator = create_unet_network(image_size, num_classes, conv_layers, kernel_size, padding, p_dropout, p_spatial,lrate,channels, batch_norm, activation_conv)
    discriminator = create_discriminator(image_size, num_classes, channels,p_dropout,p_spatial,lrate,batch_norm, alpha)
    gan = create_gan(generator, discriminator,lrate)
    return discriminator, generator, gan

