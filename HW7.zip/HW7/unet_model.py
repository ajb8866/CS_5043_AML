import tensorflow as tf
from tensorflow.keras.layers import Input,Concatenate,Conv2D,UpSampling2D,MaxPooling2D
from tensorflow.keras.models import Model
from network_support import create_conv_stack

def create_unet_network(image_size,num_classes,conv_layers,kernel_size,padding,p_dropout,p_spatial,
    lrate,rgb_channel,batch_norm,activation_conv):
    
    """
    Constructs a U-Net model with configurable parameters for image segmentation with added noise tensors 
    at different scales. 
    
    :param image_size: Size (height and width) of the input image.
    :param num_classes: Number of classes for semantic segmentation, indicating the depth of the label input.
    :param conv_layers: List of dictionaries, each describing the configuration of layers in the network.
    :param kernel_size: Size of the convolution kernels.
    :param padding: Type of padding for the convolutions ('same' or 'valid').
    :param p_dropout: Probability of dropout in each convolutional block.
    :param p_spatial: Probability of spatial dropout in each convolutional block.
    :param lrate: Learning rate for the optimizer.
    :param rgb_channel: Number of output channels (e.g., 3 for RGB image output).
    :param batch_norm: Whether to include batch normalization layers.
    :param activation_conv: Activation function used in the convolutional layers.
    """
    # Define the inputs for the U-Net: one for semantic labels and multiple for noise tensors at different scales
    inputs = Input(shape=(image_size, image_size, num_classes), name="semantic_label_input")
    
    noise_tensors = []
    for i in range(len(conv_layers)):
        scale_factor = 2 ** i
        noise_size = max(1, image_size // scale_factor)  # Ensure the size does not drop below 1
        noise_tensor = Input(shape=(noise_size, noise_size, 1), name=f"noise_{i + 1}")
        noise_tensors.append(noise_tensor)
    
    # Downsampling path with convolutions and max pooling
    x = inputs
    skips = []
    for i, layer in enumerate(conv_layers):
        x = create_conv_stack(x, i, layer['conv_count'], layer['filters'], kernel_size, padding, activation=activation_conv, batch_normalization=batch_norm, sdropout=p_spatial, dropout=p_dropout)
        skips.append(x)
        x = MaxPooling2D(pool_size=(layer['pool_size']), name=f'pool_{i}')(x)

    # Bottleneck part of U-Net
    x = create_conv_stack(x, len(conv_layers), 2, conv_layers[-1]['filters'] * 2, kernel_size, padding, activation=activation_conv, batch_normalization=batch_norm, sdropout=p_spatial, dropout=p_dropout)

    # Upsampling path with concatenation of skip connections and noise tensors
    noise_inputs = reversed(noise_tensors)
    for i, (layer, noise_input) in enumerate(zip(reversed(conv_layers), noise_inputs)):
        # Upsampling before concatenation with skip connection and noise
        x = UpSampling2D(size=(layer["pool_size"]), name=f"up_sample_{i}")(x)
        skip = skips.pop()
        # Calculate the scale needed to match the skip connection
        scale = (skip.shape[1] // noise_input.shape[1], skip.shape[2] // noise_input.shape[2])
        noise_resized = UpSampling2D(size=scale)(noise_input)
        # Concatenate skip, upsampled layer, and resized noise input
        x = Concatenate()([x, skip, noise_resized])

    # Output layer to produce the final RGB image
    x = Conv2D(rgb_channel, (1, 1), padding=padding, activation="tanh", name="output_layer")(x)

    # Compile the model with Adam optimizer and a suitable loss function
    #Used to moniter the progress of GAN despite not being used traditionally 
    model = Model(inputs=[inputs, noise_tensors[0], noise_tensors[1], noise_tensors[2], noise_tensors[3]], outputs=x, name="UNet")
    model.compile(
        optimizer=tf.optimizers.Adam(learning_rate=lrate),
        loss=tf.keras.losses.SparseCategoricalCrossentropy(),
        metrics=[tf.keras.metrics.SparseCategoricalAccuracy()],
    )

    return model