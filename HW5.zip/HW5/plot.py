import matplotlib.pyplot as plt
import numpy as np
import os
import pickle
import tensorflow as tf
from tensorflow.keras.models import load_model
from tensorflow.keras.preprocessing import image



RNN_RESULTS_DIR = '/home/ajb8866/HW5/results/rnn/stuff'
CNN_RESULTS_DIR = '/home/ajb8866/HW5/results/cnn'
PLOTS_DIR = '/home/ajb8866/HW5/results/plots'


def load_results_from_dir(directory):
    """
    Load all result files from a given directory.

    :param directory: Directory containing result files.
    :return: List of loaded result files.
    """
    results = []
    for filename in os.listdir(directory):
        if filename.endswith('.pkl'):
            with open(os.path.join(directory, filename), 'rb') as file:
                results.append(pickle.load(file))
    return results
   

def extract_metrics(results):
    """
    Extract validation loss and accuracy from results.

    :param results: List of results.
    :return: Lists of validation loss, validation accuracy, and test accuracy.
    """
    val_losses = []
    val_accuracies = []
    test_accuracies = []
    test_accuracies_final =[]
    for result in results:
        val_losses.append(result['history']['val_loss'])
        val_accuracies.append(result['history']['val_sparse_categorical_accuracy'])
        test_accuracies.append(result['history']['sparse_categorical_accuracy'])
        test_accuracies_final.append(result['predict_testing_eval'][1])
    return val_losses, val_accuracies, test_accuracies, test_accuracies_final

def get_color_shades(base_color, num_shades):
    """
    Generate different shades of a base color.
    
    :param base_color: A matplotlib color string.
    :param num_shades: Number of shades to generate.
    :return: List of color shades.
    """
    base = plt.get_cmap(base_color) 
    return [base(1. * i/num_shades) for i in range(num_shades)]

def plot_combined_test_accuracy(cnn_test_accuracies, rnn_test_accuracies):
    """
    Plot learning curves for test accuracy for both CNN and RNN models on the same graph.

    :param cnn_test_accuracies: List of test accuracies for CNN models.
    :param rnn_test_accuracies: List of test accuracies for RNN models.
    """
    plt.figure(figsize=(10, 8))
    cnn_colors = get_color_shades('ocean', len(cnn_test_accuracies))
    rnn_colors = get_color_shades('plasma', len(rnn_test_accuracies))
    for i, acc in enumerate(cnn_test_accuracies):
        epochs = range(1, len(acc) + 1)
        plt.plot(epochs, acc, label=f'CNN Rotation {i}', linestyle='dotted', color=cnn_colors[i])
    for i, acc in enumerate(rnn_test_accuracies):
        epochs = range(1, len(acc) + 1)
        plt.plot(epochs, acc, label=f'RNN Rotation {i}', linestyle='--', color=rnn_colors[i])
    plt.title(f'Test Accuracy')
    plt.xlabel('Epochs')
    plt.ylabel('Accuracy')
    plt.legend()
    plt.tight_layout()
    plt.savefig(os.path.join(PLOTS_DIR, f"Test_Accuracy.png"))
    plt.clf()
    
def plot_combined_validation_accuracy(cnn_val_accuracies, rnn_val_accuracies):
    """
    Plot learning curves for validation accuracy for both CNN and RNN models on the same graph.

    :param cnn_val_accuracies: List of validation accuracies for CNN models.
    :param rnn_val_accuracies: List of validation accuracies for RNN models.
    :param title: Title for the plot.
    """
    plt.figure(figsize=(10, 8))
    cnn_colors = get_color_shades('ocean', len(cnn_val_accuracies))
    rnn_colors = get_color_shades('plasma', len(rnn_val_accuracies))
    for i, acc in enumerate(cnn_val_accuracies):
        epochs = range(1, len(acc) + 1)
        plt.plot(epochs, acc, label=f'CNN Rotation {i}', linestyle='dotted', color=cnn_colors[i])
    for i, acc in enumerate(rnn_val_accuracies):
        epochs = range(1, len(acc) + 1)
        plt.plot(epochs, acc, label=f'RNN Rotation {i}', linestyle='--', color=rnn_colors[i])
    plt.title('Valdiation Accuracy')
    plt.xlabel('Epochs')
    plt.ylabel('Accuracy')
    plt.legend()
    plt.tight_layout()
    plt.savefig(os.path.join(PLOTS_DIR, f"Validation_Accuracy.png"))
    plt.clf()
   
def plot_validation_loss(val_losses, title_prefix):
    """
    Plot learning curves for validation loss.

    :param val_losses: List of validation losses.
    :param title_prefix: Prefix for the plot title.
    """
    plt.figure(figsize=(10, 8))
    for i, loss in enumerate(val_losses):
        epochs = range(1, len(loss) + 1)
        plt.plot(epochs, loss, label=f'Rotation {i}')
    plt.title(f'{title_prefix} Validation Loss')
    plt.xlabel('Epochs')
    plt.ylabel('Loss')
    plt.legend()
    plt.tight_layout()
    plt.savefig(f"{title_prefix}_Validation_Loss.png")
    plt.clf()
    

def plot_bar_chart(test_accuracies_cnn, test_accuracies_rnn):
    """
    Generate a bar chart of test set accuracy for cnn and rnn models, positioning
    the bars next to each other for direct comparison.
    """
    n_groups = 5
    index = np.arange(n_groups)  # Positions for the groups
    bar_width = 0.35  # Width of the bars

    # Plot bars for cnn models
    plt.bar(index - bar_width/2, test_accuracies_cnn, bar_width,
            alpha=1, color='skyblue', label='cnn')

    # Plot bars for rnn models, shifted right by bar_width
    plt.bar(index + bar_width/2, test_accuracies_rnn, bar_width,
            alpha=1, color='tomato', label='rnn')

    # Set the x-axis label, y-axis label, and chart title
    plt.xlabel('Rotation')
    plt.ylabel('Test Accuracy')
    plt.title('Test Accuracy by Model Type and Rotation')

    # Set the position of the ticks and their labels
    plt.xticks(index, ('Rotation 0', 'Rotation 1', 'Rotation 2', 'Rotation 3', 'Rotation 4'))

    # Add a legend to the chart
    plt.legend()

    # Adjust the layout to make room for the tick labels
    plt.tight_layout()

    # Save the figure
    plt.savefig("Test_Accuracy_Bar_Chart.png")
    plt.clf() 


def plot_test_accuracy_scatter(cnn_test_accuracies, rnn_test_accuracies):
    """
    Plot a scatter plot comparing the test set accuracy of CNN and RNN models.

    :param cnn_test_accuracies: List of test accuracies for CNN models.
    :param rnn_test_accuracies: List of test accuracies for RNN models.
    """
    # Generate figure and axis
    plt.figure(figsize=(10, 8))
    
    # Plot each pair of CNN and RNN test accuracy
    for i in range(len(cnn_test_accuracies)):
        plt.scatter(i, cnn_test_accuracies[i], color='skyblue', label='CNN' if i == 0 else "")
        plt.scatter(i, rnn_test_accuracies[i], color='tomato', label='RNN' if i == 0 else "")
    
    # Adding labels and title
    plt.xlabel('Rotation')
    plt.ylabel('Test Set Accuracy')
    plt.title('Plot of Test Set Accuracy: RNN vs CNN')
    plt.legend()
    
    # Save the plot
    plt.tight_layout()
    plt.savefig(os.path.join(PLOTS_DIR, "RNN_vs_CNN_Test_Accuracy_Scatter.png"))
    plt.clf()


    
if __name__ == "__main__":
    os.makedirs(PLOTS_DIR, exist_ok=True)

    # Load results
    cnn_results = load_results_from_dir(CNN_RESULTS_DIR)
    rnn_results = load_results_from_dir(RNN_RESULTS_DIR)
    
    # Extract metrics
    cnn_val_losses, cnn_val_accuracies, cnn_test_accuracies, cnn_test_accuracies_final = extract_metrics(cnn_results)
    rnn_val_losses, rnn_val_accuracies, rnn_test_accuracies, rnn_test_accuracies_final = extract_metrics(rnn_results)

    # Plot validation accuracy and loss for cnn models
    plot_combined_validation_accuracy(cnn_val_accuracies, rnn_val_accuracies)
    plot_combined_test_accuracy(cnn_test_accuracies, rnn_test_accuracies)

    plot_validation_loss(cnn_val_losses, "cnn")
    
    plot_validation_loss(rnn_val_losses, "rnn")
    
    plot_bar_chart(cnn_test_accuracies_final, rnn_test_accuracies_final)
    
    plot_test_accuracy_scatter(cnn_test_accuracies_final, rnn_test_accuracies_final)

        