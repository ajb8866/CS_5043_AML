import tensorflow as tf
from tensorflow.keras.layers import Input, SimpleRNN, Bidirectional, AveragePooling1D, Conv1D, MaxPooling1D, GlobalAveragePooling1D, Dense, Dropout, Embedding
from tensorflow.keras.models import Model
from tensorflow.keras import regularizers

def create_model(input_length, n_tokens, n_classes, model_type, rnn_units, conv_filters, kernel_size, pool_size, activation, padding, dropout_rate, l1_reg, l2_reg, lrate, hidden, activation_dense):
    """
    Constructs and compiles a TensorFlow model based on the specified type (RNN or CNN).
    
    :param input_length: Length of the input sequences.
    :param n_tokens: Number of unique tokens in the dataset (vocabulary size).
    :param n_classes: Number of classes for classification.
    :param model_type: Type of model to create ('rnn' for Recurrent Neural Network, 'cnn' for Convolutional Neural Network).
    :param rnn_units: List of units for each RNN layer (used when model_type is 'rnn').
    :param conv_filters: List of filters for each Convolutional layer (used when model_type is 'cnn').
    :param kernel_size: Size of the kernels for convolutional layers (list if varies per layer).
    :param pool_size: Size of the pooling windows (list if varies per layer).
    :param activation: Activation function for the convolutional layers.
    :param padding: Padding strategy for convolutional layers.
    :param dropout_rate: Dropout rate for regularization.
    :param l1_reg: L2 regularization factor. If 0, no L2 regularization is added.
    :param l2_reg:  L1 regularization factor. If 0, no L1 regularization is added.
    :param lrate: Learning rate for the optimizer.
    :param hidden: List of units for each Dense layer in the model.
    :param activation_dense: Activation function for the Dense layers.
    """
    
    # Input layer specification
    inputs = Input(shape=(input_length,), name='input_layer')
    
    x = Embedding(input_dim=n_tokens, output_dim=16, input_length=input_length)(inputs)
    
    regularizer = regularizers.l1_l2(l1=l1_reg, l2=l2_reg) if l1_reg or l2_reg else None
    
    # Construct RNN model layers if model type is RNN
    if model_type == 'rnn':
        for i, units in enumerate(rnn_units):
            # Determine if the RNN layer should return sequences based on its position
            return_sequences = i < len(rnn_units) - 1  
            rnn_layer = SimpleRNN(units, return_sequences=return_sequences,
                                  recurrent_dropout=dropout_rate,
                                  kernel_regularizer=regularizer,
                                  unroll=True)
            # Add bidirectional wrapper to RNN layer for capturing patterns in both directions
            x = Bidirectional(rnn_layer, name=f'bidirectional_rnn_{i+1}')(x)
            if return_sequences and pool_size:
                current_pool_size = pool_size[i] if isinstance(pool_size, list) else pool_size
                x = AveragePooling1D(pool_size=current_pool_size, name=f'average_pooling_{i+1}')(x)
                
    # Construct CNN model layers if model type is CNN
    elif model_type == 'cnn':
        for i, filters in enumerate(conv_filters):
            # Convolutional layer with specified filters, kernel size, and activation
            x = Conv1D(filters=filters,
                       kernel_size=kernel_size[i],
                       activation=activation,
                       padding=padding,
                       kernel_regularizer=regularizer,
                       name=f'conv1d_{i+1}')(x)
            # Pooling layer to reduce dimensionality and overfitting
            x = MaxPooling1D(pool_size=pool_size[i], name=f'max_pooling_{i+1}')(x)
            # Dropout for regularization
            x = Dropout(dropout_rate, name=f'dropout_conv_{i+1}')(x)
        # Global pooling to reduce the features to a single vector per feature map
        x = GlobalAveragePooling1D(name='global_average_pooling')(x)
    
    # Dense layers for further learning with dropout for regularization
    for i, units in enumerate(hidden):
        x = Dense(units, activation=activation_dense, name=f'dense_{i+1}')(x)
        if dropout_rate is not None:
            x = Dropout(dropout_rate, name=f'dropout_{i+1}')(x)
            
    outputs = Dense(n_classes, activation='softmax', kernel_regularizer=regularizer, name='output')(x)
        
    # Assemble and compile the model with appropriate optimizer and loss function
    model = Model(inputs=inputs, outputs=outputs, name=f"{model_type.upper()}_Model")
    if model_type == 'rnn':         
        model.compile(optimizer=tf.optimizers.Adam(learning_rate=lrate, clipnorm=0.5),
                      loss=tf.keras.losses.SparseCategoricalCrossentropy(),
                      metrics=[tf.keras.metrics.SparseCategoricalAccuracy()])
    else:
        model.compile(optimizer=tf.optimizers.Adam(learning_rate=lrate),
                      loss=tf.keras.losses.SparseCategoricalCrossentropy(),
                      metrics=[tf.keras.metrics.SparseCategoricalAccuracy()])

    return model
