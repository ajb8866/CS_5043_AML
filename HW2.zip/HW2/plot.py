import os
import matplotlib.pyplot as plt
import numpy as np
import pickle
import argparse
import fnmatch
from scipy.stats import ttest_rel


def create_plotting_parser():
    '''
    Initializes an argument parser for the plotting script, defining necessary command-line options.
    '''
    # Initialize an argument parser for command-line options
    parser = argparse.ArgumentParser(description='Plotting utility for BMI analysis results')
    parser.add_argument('--results_path', type=str, default='./results',
                        help='Directory containing the results files to plot')
    parser.add_argument('--plot_type', type=str, choices=['training_folds', 'fvaf_dropout', 'fvaf_lx', 'best_hyper'],
                        help='Type of plot to generate: training_folds, fvaf_dropout, fvaf_lx, or best_hyper')
    parser.add_argument('--file_pattern', type=str, default='*.pkl',
                        help='Pattern to match result files (e.g., "*_results.pkl")')
    return parser

def read_results(dirname, file_pattern):
    '''
    Reads and loads results from files matching a specific pattern within a directory.
    
    :param dirname: The directory path where result files are located.
    :param file_pattern: The pattern used to match files within the directory.
    '''
    # List and sort files matching the given pattern in the specified directory
    files = fnmatch.filter(os.listdir(dirname), file_pattern)
    files.sort()
    results = []
    for f in files:
        with open(os.path.join(dirname, f), "rb") as fp:
            results.append(pickle.load(fp))
    return results
    
def compute_fvaf_averages(results):
    '''
    Computes average Fraction of Variance Accounted For (FVAF) scores for each training size across multiple results.
    
    :param results: A list of result objects containing evaluation metrics and fold information.
    '''
    # Calculate and return average FVAF scores for different training sizes      
    fvaf_data = {
        'training_sizes': [],
        'avg_training_fvafs': [],
        'avg_validation_fvafs': [],
        'avg_testing_fvafs': []
    }
    
    fvaf_scores = {}

    for result in results:
        # Extract FVAF scores and training sizes
        training_size = len(result['folds']['folds_training'])
        training_fvaf = result['predict_training_eval'][1]
        validation_fvaf = result['predict_validation_eval'][1]
        testing_fvaf = result['predict_testing_eval'][1]
       
        # Aggregate FVAF scores by training size        
        if training_size not in fvaf_scores:
            fvaf_scores[training_size] = {'training': [], 'validation': [], 'testing': []}
        
        fvaf_scores[training_size]['training'].append(training_fvaf)
        fvaf_scores[training_size]['validation'].append(validation_fvaf)
        fvaf_scores[training_size]['testing'].append(testing_fvaf)
    # Calculate average FVAF scores and sort by training size    
    for size, scores in fvaf_scores.items():
        fvaf_data['training_sizes'].append(size)
        fvaf_data['avg_training_fvafs'].append(np.mean(scores['training']))
        fvaf_data['avg_validation_fvafs'].append(np.mean(scores['validation']))
        fvaf_data['avg_testing_fvafs'].append(np.mean(scores['testing']))

    # Sort the results by training size before returning
    # Get the sorted order of indices based on training sizes
    sorted_indices = np.argsort(fvaf_data['training_sizes'])
    
    # Use the sorted indices to sort all lists in fvaf_data
    for key in fvaf_data:
        fvaf_data[key] = [fvaf_data[key][i] for i in sorted_indices]
    
    return fvaf_data    

def plot_fvaf_averages(fvaf_data, save_path='fig1_fvaf.png'):
    '''
    Generates and saves a plot of average FVAF scores across different numbers of training folds.
    
    :param fvaf_data: A dictionary containing training sizes and their corresponding average FVAF scores.
    :param save_path: The path where the plot image will be saved.
    '''
    # Create and save a plot of FVAF averages across training sizes
    plt.figure(figsize=(10, 6))
    plt.plot(fvaf_data['training_sizes'], fvaf_data['avg_training_fvafs'], label='Training FVAF', color='red')
    plt.plot(fvaf_data['training_sizes'], fvaf_data['avg_validation_fvafs'], label='Validation FVAF', color = 'skyblue')    
    plt.xlabel('Size of Training Set')
    plt.ylabel('Average FVAF')
    plt.title('FVAF as a Function of Training Set Size')
    plt.legend()
    plt.grid(True)
    plt.savefig(save_path)

def compute_fvaf_averages_dropout(results):
    '''
    Computes average validation FVAF scores for each training size across multiple results taking into account 
    the dropout hyperparameter
    
    :param results: A list of result objects containing evaluation metrics and fold information.
    '''
    
    fvaf_data_dropout = {}

    for result in results:
        dropout_prob = result['dropout_prob']
        training_size = len(result['folds']['folds_training'])
        validation_fvaf = result['predict_validation_eval'][1]

        if dropout_prob not in fvaf_data_dropout:
            fvaf_data_dropout[dropout_prob] = {}
        if training_size not in fvaf_data_dropout[dropout_prob]:
            fvaf_data_dropout[dropout_prob][training_size] = []

        fvaf_data_dropout[dropout_prob][training_size].append(validation_fvaf)

    # Process to calculate averages
    for dropout_prob, sizes in fvaf_data_dropout.items():
        for size in sizes:
            fvaf_data_dropout[dropout_prob][size] = np.mean(fvaf_data_dropout[dropout_prob][size])

    return fvaf_data_dropout

def plot_fvaf_dropout(fvaf_data_dropout, save_path='fig2_fvaf_dropout.png'):
    '''
    Generates and saves a plot of average FVAF scores across different numbers of training folds taking into account dropout.
    
    :param fvaf_data_dropout: A dictionary containing dropout and training sizes and their corresponding average FVAF scores.
    :param save_path: The path where the plot image will be saved.
    '''
    plt.figure(figsize=(10, 6))
    all_sizes = []  # List to store all sizes for x-axis limit adjustment
    for dropout_prob, data in fvaf_data_dropout.items():
        sizes = sorted(data.keys())
        all_sizes.extend(sizes)  # Append sizes for this dropout_prob to the list
        avg_fvafs = [data[size] for size in sizes]
        plt.plot(sizes, avg_fvafs, label=f'Dropout {dropout_prob}')
    
    plt.xlabel('Training Set Size')
    plt.ylabel('Average Validation FVAF')
    plt.title('Validation FVAF as a Function of Training Set Size and Dropout Probability')
    plt.legend()
    plt.grid(True)
    # Set x-axis limits to minimum and maximum of all training sizes    
    plt.ylim(0, 0.9)
    plt.savefig(save_path)
    
def compute_fvaf_averages_l1(results):
    '''
    Computes average validation FVAF scores for each training size across multiple results taking into account 
    the l1 regularization hyperparameter
    
    :param results: A list of result objects containing evaluation metrics and fold information.
    '''
    
    fvaf_data_l1 = {}

    for result in results:
        l1_reg = result['args'].L1_regularization  
        training_size = len(result['folds']['folds_training'])
        validation_fvaf = result['predict_validation_eval'][1]

        if l1_reg not in fvaf_data_l1:
            fvaf_data_l1[l1_reg] = {}
        if training_size not in fvaf_data_l1[l1_reg]:
            fvaf_data_l1[l1_reg][training_size] = []

        fvaf_data_l1[l1_reg][training_size].append(validation_fvaf)

    # Process to calculate averages
    for l1_reg, sizes in fvaf_data_l1.items():
        for size in sizes:
            fvaf_data_l1[l1_reg][size] = np.mean(fvaf_data_l1[l1_reg][size])

    return fvaf_data_l1

def plot_fvaf_l1(fvaf_data_l1, save_path='fig3_fvaf_l1.png'):
    '''
    Generates and saves a plot of average FVAF scores across different numbers of training folds taking into account l1 reg.
    
    :param fvaf_data: A dictionary containing l1 reg and training sizes and their corresponding average FVAF scores.
    :param save_path: The path where the plot image will be saved.
    '''
    plt.figure(figsize=(10, 6))
    # List to store all sizes for x-axis limit adjustment
    all_sizes = []  
    for l1_reg, data in fvaf_data_l1.items():
        # Append sizes for this l1_reg to the list
        sizes = sorted(data.keys())
        all_sizes.extend(sizes)  
        avg_fvafs = [data[size] for size in sizes]
        plt.plot(sizes, avg_fvafs, label=f'L1 Reg {l1_reg}')
    
    plt.xlabel('Training Set Size')
    plt.ylabel('Average Validation FVAF')
    plt.title('Validation FVAF as a Function of Training Set Size and L1 Regularization')
    plt.legend()
    plt.grid(True)
    plt.savefig(save_path)


def find_best_hyperparameters(results):
    # Structures to store the results
    dropout_results = {}
    l1_results = {}
    no_reg_results = {}

    # Iterate over all results to categorize them into dropout, L1, or no regularization
    for result in results:
        training_size = len(result['folds']['folds_training'])
        hidden_layers = tuple(result['args'].hidden)
        validation_fvaf = result['predict_validation_eval'][1]
        dropout_prob = result['args'].dropout
        l1_reg = result['args'].L1_regularization

        # Using a tuple (training_size, hidden_layers, reg_param) as key
        key = (training_size, hidden_layers)

        if dropout_prob is not None:
            if key not in dropout_results:
                dropout_results[key] = []
            dropout_results[key].append((dropout_prob, validation_fvaf))

        elif l1_reg is not None:
            if key not in l1_results:
                l1_results[key] = []
            l1_results[key].append((l1_reg, validation_fvaf))
        else:
            # Store both the configuration and its validation FVAF
            if key not in no_reg_results:
                no_reg_results[key] = []
            no_reg_results[key].append(validation_fvaf)


    # Process to find the best hyperparameter for each training size and hidden layers configuration
    best_dropout = {}
    best_l1 = {}
    best_no_reg = {}

    for key, values in dropout_results.items():
        values_array = np.array(values)
        # Find the index of the highest validation FVAF
        best_index = np.argmax(values_array[:, 1])
        # Get the corresponding dropout probability  
        best_dropout[key] = values_array[best_index, 0]  

    for key, values in l1_results.items():
        values_array = np.array(values)
        # Find the index of the highest validation FVAF
        best_index = np.argmax(values_array[:, 1])
        # Get the corresponding L1 regularization value
        best_l1[key] = values_array[best_index, 0] 

    return best_dropout, best_l1
    
def compute_mean_test_performance(test_performances):
    """
    Computes the mean test performance for each training set size.
    
    :param test_performances: A dictionary where keys are training set sizes and values are lists of test performances.
    :param no_reg: This parameter is no longer needed given the updated logic, but kept for compatibility.
    """
    # Compute the mean of performance values for each training set size
    mean_test_performance = {size: np.mean(perfs) for size, perfs in test_performances.items()}
    
    return mean_test_performance


def extract_test_performance_distributions(results, best_hyperparameters):
    """
    Extracts test performance distributions for models with the best hyperparameters.

    :param results: A list of result objects containing evaluation metrics and model configurations.
    :param best_hyperparameters: A dictionary containing the best hyperparameter values for dropout and L1 regularization, 
    HW2/fig4_fvaf_mean.pngindexed by training set size and hidden layers configuration.

    """
    # Initialize dictionaries to store test performances
    test_performances_dropout = {}
    test_performances_l1 = {}
    test_performances_no_reg = {}

    # Loop over the original results to match with best hyperparameters
    for result in results:
        training_size = len(result['folds']['folds_training'])
        hidden_layers = tuple(result['args'].hidden)
        test_fvaf = result['predict_testing_eval'][1]
        dropout_prob = result['args'].dropout
        l1_reg = result['args'].L1_regularization

        # Key for indexing into best_hyperparameters
        key = (training_size, hidden_layers)

        # Check for Dropout regularization
        if dropout_prob is not None:
            # If the current dropout_prob matches the best hyperparameter for this configuration
            if key in best_hyperparameters['dropout'] and dropout_prob == best_hyperparameters['dropout'][key]:
                if training_size not in test_performances_dropout:
                    test_performances_dropout[training_size] = []
                test_performances_dropout[training_size].append(test_fvaf)

        # Check for L1 regularization
        elif l1_reg is not None:
            # If the current l1_reg matches the best hyperparameter for this configuration
            if key in best_hyperparameters['l1'] and l1_reg == best_hyperparameters['l1'][key]:
                if training_size not in test_performances_l1:
                    test_performances_l1[training_size] = []
                test_performances_l1[training_size].append(test_fvaf)

        # No regularization case
        else:
            # For no regularization, all configurations are "best" as there's no hyperparameter to optimize
            if training_size not in test_performances_no_reg:
                test_performances_no_reg[training_size] = []
            test_performances_no_reg[training_size].append(test_fvaf)

    return test_performances_no_reg, test_performances_dropout, test_performances_l1


def plot_mean_test_performance(no_reg_performance, dropout_performance, l1_performance,  save_path='fig4_fvaf_mean.png'):
    """
    Plots the mean test set performance (FVAF) as a function of training set size for no regularization, dropout, and L1 regularization.
    

    :param no_reg_performance: Mean test performance for no regularization.
    :param dropout_performance: Mean test performance for dropout.
    :param l1_performance: Mean test performance for L1 regularization.
    :param save_path: File path to save the plot image.
    """
   
    # Prepare data for plotting
    training_sizes = sorted(no_reg_performance.keys())
    no_reg_fvaf = [no_reg_performance[n] for n in training_sizes]
    dropout_fvaf = [dropout_performance[n] for n in training_sizes]
    l1_fvaf = [l1_performance[n] for n in training_sizes]
    
    # Plotting
    plt.figure(figsize=(10, 6))
    plt.plot(training_sizes, no_reg_fvaf, label='No Regularization', color='dimgrey')
    plt.plot(training_sizes, dropout_fvaf, label='Dropout', color='darkgoldenrod')
    plt.plot(training_sizes, l1_fvaf, label='L1 Regularization', color='blueviolet')
    
    plt.title('Mean Test Set Performance (FVAF) by Training Set Size')
    plt.xlabel('Training Set Size')
    plt.ylabel('Mean Test Set Performance (FVAF)')
    plt.ylim(0.71, 0.845)
    plt.legend()
    plt.grid(True)
    plt.tight_layout()
    plt.show()
    plt.savefig(save_path)

    return results


def perform_paired_t_tests_with_distributions(test_performance_distributions, training_set_sizes):
    """
    Performs paired t-tests between groups of test performance distributions for specified training set sizes.
    It conducts paired t-tests between each pair of regularization techniques to determine if there are statistically significant differences in their performances.
    
    Parameters:
    :param test_performance_distributions: A dictionary containing test performance distributions for models with different 
    :param regularization techniques, indexed by training set size.
    :param training_set_sizes: A list of training set sizes for which to perform the t-tests.
    """    
    results = {}
    for size in training_set_sizes:
        performances_no_reg = test_performance_distributions['no_reg'].get(size, [])
        performances_dropout = test_performance_distributions['dropout'].get(size, [])
        performances_l1 = test_performance_distributions['l1'].get(size, [])

        # Initialize default values in case of insufficient data
        p_value_no_reg_vs_dropout = 'N/A'
        p_value_no_reg_vs_l1 = 'N/A'
        p_value_dropout_vs_l1 = 'N/A'

        # Perform t-test between no regularization and dropout regularization, if sufficient data is available.
        if len(performances_no_reg) > 1 and len(performances_dropout) > 1:
            _, p_value_no_reg_vs_dropout = ttest_rel(performances_no_reg, performances_dropout)

        # Perform t-test between no regularization and L1 regularization, if sufficient data is available.
        if len(performances_no_reg) > 1 and len(performances_l1) > 1:
            _, p_value_no_reg_vs_l1 = ttest_rel(performances_no_reg, performances_l1)

        # Perform t-test between dropout regularization and L1 regularization, if sufficient data is available.
        if len(performances_dropout) > 1 and len(performances_l1) > 1:
            _, p_value_dropout_vs_l1 = ttest_rel(performances_dropout, performances_l1)

        results[size] = {
            'no_reg_vs_dropout': p_value_no_reg_vs_dropout,
            'no_reg_vs_l1': p_value_no_reg_vs_l1,
            'dropout_vs_l1': p_value_dropout_vs_l1,
        }

    return results



if __name__ == "__main__":
    parser = create_plotting_parser()
    args = parser.parse_args()

    results = read_results(args.results_path, args.file_pattern)

    # Generate the requested plot type based on command-line arguments
    if args.plot_type == 'training_folds':
        fvaf_data = compute_fvaf_averages(results)
        plot_fvaf_averages(fvaf_data)
    elif args.plot_type == 'fvaf_dropout':
        fvaf_data_dropout = compute_fvaf_averages_dropout(results)
        plot_fvaf_dropout(fvaf_data_dropout)
    elif args.plot_type == 'fvaf_lx': 
        fvaf_data_l1 = compute_fvaf_averages_l1(results)
        plot_fvaf_l1(fvaf_data_l1)
    elif args.plot_type == 'best_hyper': 
     # Find the best hyperparameters results for no regularization, dropout, and L1 regularization
      
        best_dropout_results, best_l1_results, best_no_reg = find_best_hyperparameters(results)
        best_hyperparameters = { 'dropout': best_dropout_results,
                          'l1': best_l1_results
                        }
        test_performances_no_reg, test_performances_dropout, test_performances_l1 = extract_test_performance_distributions(results, best_hyperparameters)
        mean_test_performance_no_reg = compute_mean_test_performance(test_performances_no_reg, no_reg=True)
        mean_test_performance_dropout = compute_mean_test_performance(test_performances_dropout)
        mean_test_performance_l1 = compute_mean_test_performance(test_performances_l1)
        plot_mean_test_performance(mean_test_performance_no_reg, mean_test_performance_dropout, mean_test_performance_l1, save_path='fig4_fvaf_mean.png')
        
        t_test_results = perform_paired_t_tests_with_distributions({
            'no_reg': test_performances_no_reg,
            'dropout': test_performances_dropout,
            'l1': test_performances_l1,
        }, [1, 18])
        
        # Print t-test results
        for size in [1, 18]:  
            print(f"Training Set Size: {size}")
            for comparison, p_value in t_test_results[size].items():
                print(f"{comparison}: p-value = {p_value if p_value is not None else 'N/A'}")