#!/bin/bash
# SLURM script for hw2 test run

#SBATCH --partition=disc
#SBATCH --ntasks=2
#SBATCH --cpus-per-task=2
#SBATCH --mem=4G 
#SBATCH --output=results/hw2_%A_%a_stdout.txt
#SBATCH --error=results/hw2_%A_%a_stderr.txt
#SBATCH --time=00:15:00
#SBATCH --job-name=hw2
#SBATCH --mail-user=Averi.J.Bates-1@ou.edu
#SBATCH --mail-type=ALL
#SBATCH --chdir=/home/ajb8866/HW2
#SBATCH --array=0-1
#SBATCH --exclusive


# Load your environment or modules
. /home/fagg/tf_setup.sh
conda activate dnn

# Execute your main experiment script with parameters
python hw2_base_skel.py --epochs 10 --exp_index $SLURM_ARRAY_TASK_ID --lrate 0.0125  --Ntraining 2  --rotation 1 --predict_dim 0 --hidden 10

#python plot.py  --file_pattern="*_results.pkl" --plot_type 'best_hyper' 
