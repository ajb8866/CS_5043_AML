'''
Advanced Machine Learning, 2024
HW 4 Base Code

Author: Andrew H. Fagg (andrewhfagg@gmail.com)

Image Segmentation U-Net

Updates for using caching and GPUs
- Batch file:
#SBATCH --gres=gpu:1
#SBATCH --partition=gpu
or
#SBATCH --partition=disc_dual_a100_students
#SBATCH --cpus-per-task=64

- Command line options to include
--cache $LSCRATCH                              (use lscratch to cache the datasets to local fast disk)
--batch 4096                                   (this parameter is per GPU)
--gpu
--precache datasets_by_fold_4_objects          (use a 4-object pre-constructed dataset)

Notes: 
- batch is now a parameter per GPU.  If there are two GPUs, then this number is doubled internally.
   Note that you must do other things to make use of more than one GPU
- 4096 works on the a100 GPUs
- The prcached dataset is a serialized copy of a set of TF.Datasets (located on slow spinning disk).  
Each directory contains all of the images for a single data fold within a couple of files.  Loading 
these files is *a lot* less expensive than having to load the individual images and preprocess them 
at the beginning of a run.
- The cache is used to to store the loaded datasets onto fast, local SSD so they can be fetched quickly
for each training epoch

'''

import sys
import wandb
import os
import argparse
import pickle
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import tensorflow as tf
import socket

from tensorflow.keras.utils import plot_model
from sklearn.metrics import confusion_matrix
import seaborn as sns
import matplotlib.pyplot as plt
from tensorflow.keras.callbacks import ModelCheckpoint


#############
# REMOVE THESE LINES if symbiotic_metrics, job_control, networks are in the same directory
#tf_tools = "../../../../tf_tools/"
#sys.path.append(tf_tools + "metrics")
#sys.path.append(tf_tools + "experiment_control")
#sys.path.append(tf_tools + "networks")
#############

# Provided
from job_control import *
from hw4_parser import *
from chesapeake_loader import *


# You need to provide this yourself
from unet_model import *

#################################################################
# Default plotting parameters
FIGURESIZE=(10,6)
FONTSIZE=18

plt.rcParams['figure.figsize'] = FIGURESIZE
plt.rcParams['font.size'] = FONTSIZE

plt.rcParams['xtick.labelsize'] = FONTSIZE
plt.rcParams['ytick.labelsize'] = FONTSIZE

#################################################################

def load_meta_data_set(fname = 'classes.pkl'):
    '''
    Load the metadata for a multi-class data set

    The returned data set is:
    - A python list of classes
    - Each class has a python list of object
    - Each object is described as using a DataFrame that contains file
       locations/names and class labels


    :param fname: Pickle file with the metadata

    :return: Dictionary containing class data
    '''
    obj = None
    with open(fname, "rb") as fp:
        obj = pickle.load(fp)

    assert obj is not None, "Meta-data loading error"
    print("Read %d classes\n"%obj['nclasses'])
    return obj

def exp_type_to_hyperparameters(args):
    '''
    Adjust this function to generate hyperparameters for experiments comparing shallow vs. deep models
    across different data folds for HW4's semantic labeling task.

    :param args: ArgumentParser containing command-line options.
    :return: A dictionary of hyperparameter sets, mapping parameter names to lists of values.
    '''
    # Default experiment setup with range of folds for training/validation
    if args.exp_type is None:
        # Assuming folds F5 to F9 are used for separate experiments, as specified
        p = {'fold': [5, 6, 7, 8, 9]}
    else:
        raise ValueError("Unrecognized exp_type")
    
    return p


#################################################################
def check_args(args):
    assert (args.fold in range(0, 10)), "Fold must be between 0 and 9"
    assert (args.Ntraining >= 1 and args.Ntraining <= (args.Nfolds-1)), "Ntraining must be between 1 and Nfolds-2"
    assert (args.spatial_dropout is None or (args.spatial_dropout > 0.0 and args.dropout < 1)), "Spatial dropout must be between 0 and 1"
    assert (args.dropout is None or (args.dropout > 0.0 and args.dropout < 1)), "Dropout must be between 0 and 1"
    assert (args.lrate > 0.0 and args.lrate < 1), "Lrate must be between 0 and 1"
    assert (args.L1_regularization is None or (args.L1_regularization > 0.0 and args.L1_regularization < 1)), "L1_regularizer must be between 0 and 1"
    assert (args.L2_regularization is None or (args.L2_regularization > 0.0 and args.L2_regularization < 1)), "L2_regularizer must be between 0 and 1"
    assert (args.cpus_per_task is None or args.cpus_per_task > 1), "cpus_per_task must be positive or None"
    assert args.model_type in ['shallow', 'deep'], "Model type must be 'shallow' or 'deep'"

def augment_args(args):
    '''
    Use the jobiterator to override the specified arguments based on the experiment index.

    Modifies the args

    :param args: arguments from ArgumentParser
    :return: A string representing the selection of parameters to be used in the file name
    '''
    
    # Create parameter sets to execute the experiment on.  This defines the Cartesian product
    #  of experiments that we will be executing
    p = exp_type_to_hyperparameters(args)

    # Check index number
    index = args.exp_index
    if(index is None):
        return ""
    
    # Create the iterator
    ji = JobIterator(p)
    print("Total jobs:", ji.get_njobs())
    
    # Check bounds
    assert (args.exp_index >= 0 and args.exp_index < ji.get_njobs()), "exp_index out of range"

    # Print the parameters specific to this exp_index
    print(ji.get_index(args.exp_index))
    
    # Push the attributes to the args object and return a string that describes these structures
    return ji.set_attributes_by_index(args.exp_index, args)
 
    
#################################################################

def generate_fname(args, params_str):
    '''
    Generate the base file name for output files/directories by incorporating model type.
    
    :param args: from argParse
    :params_str: String generated by the JobIterator
    '''
    # Model type
    model_type_str = f"model_{args.model_type}_"  # Add this line to include model type in the filename

    # Hidden unit configuration
    hidden_str = '_'.join(str(x) for x in args.hidden)
    
    # Conv configuration
    conv_size_str = '_'.join(str(x) for x in args.conv_size)
    conv_filter_str = '_'.join(str(x) for x in args.conv_nfilters)
    pool_str = '_'.join(str(x) for x in args.pool)
    
    # Dropout
    dropout_str = f'drop_{args.dropout:.3f}_' if args.dropout is not None else ''
     
    # Spatial Dropout
    spatial_dropout_str = f'spatial_drop_{args.spatial_dropout:.3f}_' if args.spatial_dropout is not None else ''
        
    # L1 regularization
    regularizer_l1_str = f'L1_{args.L1_regularization:.6f}_' if args.L1_regularization is not None else ''
        
    # L2 regularization
    regularizer_l2_str = f'L2_{args.L2_regularization:.6f}_' if args.L2_regularization is not None else ''
    
    # Label
    label_str = f"{args.label}_" if args.label is not None else ''
        
    # Experiment type
    experiment_type_str = f"{args.exp_type}_" if args.exp_type is not None else ''

    # learning rate
    lrate_str = f"LR_{args.lrate:.6f}_"
    
    # Assembling all parts into the filename
    filename = "%s/image_fold%0d_%s%s%sCsize_%s_Cfilters_%s_Pool_%s_hidden_%s_%s%s%s%s%sntrain_%02d" % (
        args.results_path,
        args.fold,
        experiment_type_str,
        label_str,
        model_type_str,  
        conv_size_str,
        conv_filter_str,
        pool_str,
        hidden_str, 
        dropout_str,
        spatial_dropout_str,
        regularizer_l1_str,
        regularizer_l2_str,
        lrate_str,
        args.Ntraining,
    )
    
    return filename

#################################################################
def preprocess(image, label):
    """
    Preprocesses and augments data based on specified arguments. This function applies random transformations
    to each image and label pair, with each specific transformation having a 25% chance of being applied. 
    These transformations include random rotations, width and height shifts, zooming, and random horizontal and vertical flipping.
    The use of a random chance for each transformation ensures that the augmented dataset remains diverse, 
    without all images undergoing the same modifications.
    
    :param image: The input image to preprocess and augment.
    :param label: The label corresponding to the input image, which will undergo the same transformations for consistent augmentation.
    """
    # Random rotations
    if args.rotation_times > 0 and tf.random.uniform([]) < 0.25:
        k = tf.random.uniform([], minval=0, maxval=args.rotation_times, dtype=tf.int32)
        image = tf.image.rot90(image, k=k)
        label = tf.image.rot90(label, k=k)
    
    # Width and height shift
    if args.width_shift_range > 0 and tf.random.uniform([]) < 0.25:
        w_shift = tf.random.uniform([], minval=-args.width_shift_range, maxval=args.width_shift_range)
        image = tf.keras.preprocessing.image.random_shift(image, wrg=w_shift, hrg=0, row_axis=0, col_axis=1, channel_axis=2)
        label = tf.keras.preprocessing.image.random_shift(label, wrg=w_shift, hrg=0, row_axis=0, col_axis=1, channel_axis=2)
    if args.height_shift_range > 0 and tf.random.uniform([]) < 0.25:
        h_shift = tf.random.uniform([], minval=-args.height_shift_range, maxval=args.height_shift_range)
        image = tf.keras.preprocessing.image.random_shift(image, wrg=0, hrg=h_shift, row_axis=0, col_axis=1, channel_axis=2)
        label = tf.keras.preprocessing.image.random_shift(label, wrg=0, hrg=h_shift, row_axis=0, col_axis=1, channel_axis=2)
    
    # Zoom
    if args.zoom_range > 0.0 and tf.random.uniform([]) < 0.25:
        zoom_factor = tf.random.uniform([], minval=1 - args.zoom_range, maxval=1 + args.zoom_range)
        image = tf.keras.preprocessing.image.random_zoom(image, zoom_range=(zoom_factor, zoom_factor), row_axis=0, col_axis=1, channel_axis=2)
        label = tf.keras.preprocessing.image.random_zoom(label, zoom_range=(zoom_factor, zoom_factor), row_axis=0, col_axis=1, channel_axis=2)

    # Random horizontal and vertical flipping
    if args.horizontal_flip and tf.random.uniform([]) < 0.25:
        image = tf.image.flip_left_right(image)
        label = tf.image.flip_left_right(label)

    if args.vertical_flip and tf.random.uniform([]) < 0.25:
        image = tf.image.flip_up_down(image)
        label = tf.image.flip_up_down(label)

    return image, label

##############################################################

def save_top_bottom_images(ds_test, model, results_path):
    """
    Saves the top and bottom 5 images based on prediction accuracy from the dataset.This is used show ten interesting 
    examples of images. Each image, along with its true and predicted labels, is saved in a separate .npy file 
    for easy access and analysis. 

    :param ds_test: The dataset to evaluate. Should yield tuples of (images, labels).
    :param model: The trained model used for prediction.
    :param results_path: Base directory where the images will be saved. This function will create a subdirectory within this path.
    """
    
    image_accuracies = []
    images_list = []
    true_labels_list = []
    predicted_labels_list = []

    # Collect predictions and calculate accuracies
    for images, labels in ds_test:
        true_labels = labels.numpy()
        predictions = model.predict(images)
        predicted_labels = np.argmax(predictions, axis=-1)
        
        accuracies = np.mean(np.equal(true_labels, predicted_labels), axis=(1, 2))
        image_accuracies.extend(accuracies.tolist())
        
        images_list.extend(images.numpy())
        true_labels_list.extend(true_labels)
        predicted_labels_list.extend(predicted_labels)
    
    image_accuracies = np.array(image_accuracies)
    images_list = np.array(images_list)
    true_labels_list = np.array(true_labels_list)
    predicted_labels_list = np.array(predicted_labels_list)

    top_indices = np.argpartition(image_accuracies, -5)[-5:]
    bottom_indices = np.argpartition(image_accuracies, 5)[:5]
    
    # Create a subdirectory for the .npy image files
    image_npy_dir = os.path.join(results_path, f"image_npy/{args.fold}")
    os.makedirs(image_npy_dir, exist_ok=True)


    # Save top 5 images
    for i, index in enumerate(top_indices):
        save_path = os.path.join(image_npy_dir, f"top_accuracy_image_{i}.npy")
        with open(save_path, "wb") as f:
            np.save(f, images_list[index])
            np.save(f, true_labels_list[index])
            np.save(f, predicted_labels_list[index])

    # Save bottom 5 images
    for i, index in enumerate(bottom_indices):
        save_path = os.path.join(image_npy_dir, f"bottom_accuracy_image_{i}.npy")
        with open(save_path, "wb") as f:
            np.save(f, images_list[index])
            np.save(f, true_labels_list[index])
            np.save(f, predicted_labels_list[index])

    return top_indices, bottom_indices

##############################################################
def execute_exp(args=None):
    '''
    Perform the training and evaluation for a single model
    
    :param args: Argparse arguments
    '''
    # Check the arguments
    if args is None:
        # Case where no args are given (usually, because we are calling from within Jupyter)
        #  In this situation, we just use the default arguments
        parser = create_parser()
        args = parser.parse_args([])
        
    print(f"Executing experiment index: {args.exp_index}")
    
    
    # Override arguments if we are using exp_index
    args_str = augment_args(args)
    
    # Set number of threads, if it is specified
    if args.cpus_per_task is not None:
        tf.config.threading.set_intra_op_parallelism_threads(args.cpus_per_task)
        tf.config.threading.set_inter_op_parallelism_threads(args.cpus_per_task)
    
    # Load the datasets for training, validation, and testing
    ds_train, ds_valid, ds_test, num_classes = create_datasets(
        base_dir=args.dataset,
        fold=args.fold,
        train_filt=args.train_filt,
        cache_dir=args.cache,
        repeat_train=args.repeat,
        shuffle_train=args.shuffle,
        batch_size=args.batch,
        prefetch=args.prefetch,
        num_parallel_calls=args.num_parallel_calls
    )

    print(f"Training on fold {args.fold} with {num_classes} classes.")
    print(f"Training Data: {args.train_filt}")

    # Determine if any augmentation parameters are non-default
    augment_needed = (args.rotation_times > 0 or args.width_shift_range > 0 or args.height_shift_range > 0 or 
                      args.zoom_range > 0.0 or args.horizontal_flip or args.vertical_flip)
    # Apply only if augmentation parameters are non-default
    if augment_needed:
        ds_train = ds_train.map(preprocess, num_parallel_calls=tf.data.AUTOTUNE)
    ds_train = ds_train.map(lambda image, label: (tf.cast(image, tf.float32) / 255.0, label))
    ds_valid = ds_valid.map(lambda image, label: (tf.cast(image, tf.float32) / 255.0, label))
    
    for images, labels in ds_train.take(1):  # Assuming ds_train is your training dataset
        print("Image shape:", images.shape)
        print("Labels shape:", labels.shape)
        print("Labels dtype:", labels.dtype)
        print("First few labels for the first image in the batch:\n", labels[0, :5, :5])


    ####################################################
    # Build the model
    image_size=args.image_size[0:2]
    nchannels = args.image_size[2]

    # Network config
    # NOTE: this is very specific to our implementation of create_cnn_classifier_network()
    #   List comprehension and zip all in one place (ugly, but effective).
    #   Feel free to organize this differently
    conv_layers = [{'filters': f, 'kernel_size': (s,s), 'pool_size': (p,p), 'strides': (p,p)} if p > 1
                   else {'filters': f, 'kernel_size': (s,s), 'pool_size': None, 'strides': None}
                   for s, f, p, in zip(args.conv_size, args.conv_nfilters, args.pool)]
    print("image_size = %s"%str(image_size))
    print("nchannels =  %s"%str(nchannels))
        
    print("Conv layers:\n%s", str(conv_layers))
    print("\n")
    # Build network: you must provide your own implementation
    model = create_unet_network(
        image_size,
        nchannels,
        conv_layers=conv_layers,
        model_type=args.model_type,
        kernel_size=args.kernel_size,
        padding=args.padding,
        p_dropout=args.dropout,
        p_spatial=args.spatial_dropout,
        lambda_l2=args.L2_regularization, 
        lambda_l1=args.L1_regularization, 
        lrate=args.lrate, 
        n_classes=num_classes,
        batch_norm=args.batch_normalization,
        activation_conv=args.activation_conv
    )
    
    # Report model structure if verbosity is turned on
    if args.verbose >= 1:
        print(model.summary())

    print(args)

    # Output file base and pkl file
    fbase = generate_fname(args, args_str)
    fname_out = "%s_results.pkl"%fbase
    
    # Perform the experiment?
    if(args.nogo):
        # No!
        print("NO GO")
        print(fbase)
        return

    # Check if output file already exists
    if os.path.exists(fname_out):
        # Results file does exist: exit
        print("File %s already exists"%fname_out)
        return
     
    
    run = wandb.init(project='HW4', name=f'{args.model_type}_Fold_{args.fold}_{args.exp_index}', notes=fbase, config=vars(args))
    wandb.log({'hostname': socket.gethostname()})
             
    # Callbacks
    early_stopping_cb = keras.callbacks.EarlyStopping(
        patience=args.patience,
        restore_best_weights=True,
        min_delta=args.min_delta
    )

    # Weights and Biases
    wandb_metrics_cb = wandb.keras.WandbMetricsLogger()
    
    # Define the checkpoint callback
    checkpoint_cb = ModelCheckpoint(
        f'./results/models/{args.model_type}_best_model_{args.fold}_{args.epochs}.keras',              # Path where to save the model
        save_best_only=True,          # Only save a model if `val_loss` has improved
        monitor='val_loss',           # Monitor the validation loss
        mode='min'                    # 'min' means the lowest validation loss is considered the best
    )

    # Learn
    history = model.fit(ds_train,
                        epochs=args.epochs,
                        steps_per_epoch=args.steps_per_epoch,
                        use_multiprocessing=True, 
                        verbose=args.verbose,
                        validation_data=ds_valid,
                        callbacks=[early_stopping_cb, wandb_metrics_cb, checkpoint_cb])

   
    print(f'Steps per epoch: {args.steps_per_epoch}')
    
    
    # Create generator for test set
    if ds_test is not None:
        if augment_needed:
            ds_test = ds_test.map(preprocess)
        else:
            # Apply only normalization
            ds_test = ds_test.map(lambda image, label: (tf.cast(image, tf.float32) / 255.0, label))
        top_indices, bottom_indices = save_top_bottom_images(ds_test, model, args.results_path)
        print('Saved Top and Bottom 5 Image Predcitions')
        test_predict = model.predict(ds_test)
        test_eval = model.evaluate(ds_test)
        y_true = []
        y_pred = []
        print('Collecting True Lables....')
        for images, labels in ds_test:
            # Flatten the true labels
            true_labels_flat = labels.numpy().flatten()
            y_true.extend(true_labels_flat)

            # Get predictions and flatten them
            preds = model.predict(images)
            preds_flat = np.argmax(preds, axis=-1).flatten()  # Convert from one-hot to class labels and flatten
            y_pred.extend(preds_flat)
            
        # Compute the confusion matrix
        cm = confusion_matrix(y_true, y_pred, labels=np.arange(num_classes))  # Replace `num_classes` with the actual number of classes
                
        cm_name = f"{args.model_type}_Fold_{args.fold}_confusion_matrix.png"
        plt.figure(figsize=(20, 15))
        sns.heatmap(cm, annot=True, fmt='g', cmap='YlOrRd', xticklabels=range(num_classes), yticklabels=range(num_classes))
        plt.xlabel('Predicted labels')
        plt.ylabel('True labels')
        plt.show()
        plt.savefig(cm_name)


    val_predict= model.evaluate(ds_valid)
    val_results = model.evaluate(ds_valid)

    train_predict =  model.evaluate(ds_train, steps=args.steps_per_epoch)
    train_results = model.evaluate(ds_train, steps=args.steps_per_epoch)

    # Generate results data
    results = {}
    results['args'] = args
    
    results['predict_validation'] = val_predict

    print("Evaluate Validation")
    results['predict_validation_eval'] = val_results
       
    print("Evaluate Testing")
    if ds_test is not None:
        results['predict_testing'] = test_predict
        results['predict_testing_eval'] = test_eval

    
    print("Evaluate Training")
    results['predict_training_eval'] = train_results
    results['top_indices'] = top_indices
    results['bottom_indices'] = bottom_indices
    



    results['history'] = history.history
    
    # Log the validation metrics including loss to wandb
    wandb.log({
        "Validation Loss": val_results[0], 
        "Validation Accuracy": val_results[1], 
    })

    # Create a wandb.Table to visualize validation metrics including loss
    val_table = wandb.Table(columns=["Metric", "Value"])
    val_table.add_data("Validation Loss", val_results[0])
    val_table.add_data("Validation Accuracy", val_results[1])

    # Log the table to wandb
    wandb.log({"Validation Metrics": val_table})

    if ds_test is not None:
        # Log the evaluation metrics including loss to wandb
        wandb.log({
            "Test Loss": test_eval[0], 
            "Test Accuracy": test_eval[1],            
        })

        # Create a wandb.Table to visualize metrics including loss
        table2 = wandb.Table(columns=["Metric", "Value"])
        table2.add_data("Test Loss", test_eval[0])
        table2.add_data("Test Accuracy", test_eval[1])
        # Log the table to wandb
        wandb.log({"Evaluation Metrics": table2})

    # Generate and save the model diagram with dynamic filename
    plot_model(model, to_file=f'{args.model_type}_Fold_{args.fold}_model_diagram.png', show_shapes=True, show_layer_names=True, rankdir='TB', expand_nested=True, dpi=150)
        
    # Save results
    fbase = generate_fname(args, args_str)
    results['fname_base'] = fbase
    with open("%s_results.pkl"%(fbase), "wb") as fp:
        pickle.dump(results, fp)
    
     # Save model
    if args.save_model:
        print("Saving the model...")
        model.save("%s_model"%(fbase))
        
    wandb.finish()
    print(fbase)
    
    return model


def check_completeness(args):
    '''
    Check the completeness of a Cartesian product run.

    All other args should be the same as if you executed your batch, however, the '--check' flag has been set

    Prints a report of the missing runs, including both the exp_index and the name of the missing results file

    :param args: ArgumentParser

    '''
    
    # Get the corresponding hyperparameters
    p = exp_type_to_hyperparameters(args)

    # Create the iterator
    ji = JobIterator(p)

    print("Total jobs: %d"%ji.get_njobs())

    print("MISSING RUNS:")

    indices = []
    # Iterate over all possible jobs
    for i in range(ji.get_njobs()):
        params_str = ji.set_attributes_by_index(i, args)
        # Compute output file name base
        fbase = generate_fname(args, params_str)
    
        # Output pickle file name
        fname_out = "%s_results.pkl"%(fbase)

        if not os.path.exists(fname_out):
            # Results file does not exist: report it
            print("%3d\t%s"%(i, fname_out))
            indices.append(i)

    # Give the list of indices that can be inserted into the --array line of the batch file
    print("Missing indices (%d): %s"%(len(indices),','.join(str(x) for x in indices)))

    
#################################################################
if __name__ == "__main__":
    # Parse and check incoming arguments
    parser = create_parser()
    args = parser.parse_args()
    check_args(args)
    
    # Turn off GPU?
    if not args.gpu:
        os.environ["CUDA_VISIBLE_DEVICES"] = "-1"
        
    # GPU check
    physical_devices = tf.config.list_physical_devices('GPU') 
    n_physical_devices = len(physical_devices)
    if(n_physical_devices > 0):
        for device in physical_devices:
            try:
                tf.config.experimental.set_memory_growth(device, True)
            except RuntimeError as e:
            # This exception is raised if memory growth is attempted to be set
            # after TensorFlow has already started to allocate memory.
                 print('Error setting memory growth for device %s: %s' % (device, e))

        print('We have %d GPUs\n'%n_physical_devices)
    else:
        print('NO GPU')

    if(args.check):
        # Just check to see if all experiments have been executed
        check_completeness(args)
    else:
        # Execute the experiment
        execute_exp(args)
        
