#!/bin/bash
#
#SBATCH --partition=disc
#SBATCH --cpus-per-task=16            
#SBATCH --mem=5G                           
#SBATCH --output=results/hw4_plot_%a_%j_stdout.txt  
#SBATCH --error=results/hw4_plot_%a_%j_stderr.txt   
#SBATCH --time=1:00:00                    
#SBATCH --job-name=plot                 
#SBATCH --mail-user=Averi.J.Bates-1@ou.edu 
#SBATCH --mail-type=ALL                    
#SBATCH --array=0

# Activate your environment and setup
. /home/fagg/tf_setup.sh
conda activate dnn_2024_02
module load cuDNN/8.9.2.26-CUDA-12.2.0

python plot.py 
