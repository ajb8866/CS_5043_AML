import tensorflow as tf
from tensorflow.keras.layers import Input, Conv2D, MaxPooling2D, UpSampling2D, Concatenate, Dropout, SpatialDropout2D, BatchNormalization, Activation
from tensorflow.keras.models import Model
from tensorflow.keras import regularizers

def create_conv_block(inputs, num_filters, kernel_size, padding, p_dropout, p_spatial_dropout, regularizer,batch_norm,activation_conv, name_prefix):
    """
    Creates a convolutional block, optionally including batch normalization, dropout, and spatial dropout layers.
    :param inputs: Input tensor for the convolutional block.
    :param num_filters: Number of filters for the Conv2D layer.
    :param kernel_size: Size of the kernel for the Conv2D layer.
    :param padding: Padding strategy for the Conv2D layer. Usually 'same' or 'valid'.
    :param p_dropout: Dropout rate for the Dropout layer. If 0, no dropout layer is added.
    :param p_spatial_dropout: Dropout rate for the SpatialDropout2D layer. If 0, no spatial dropout layer is added.
    :param regularizer: Regularization function applied to the kernel weights of the Conv2D layer.
    :param batch_norm: If True, a BatchNormalization layer is added after the convolution.
    :param activation_conv: Activation function to use after the optional batch normalization layer.
    :param name_prefix: Prefix for the names of layers to ensure unique layer names.
    """
    conv = Conv2D(num_filters, kernel_size, activation=None, padding=padding, kernel_regularizer=regularizer, name=f'{name_prefix}_conv')(inputs)
    if batch_norm:
        conv = BatchNormalization(name=f'{name_prefix}_batchnorm')(conv)
    conv = Activation(activation_conv, name=f'{name_prefix}_activation')(conv)
    if p_dropout > 0:
        conv = Dropout(p_dropout, name=f'{name_prefix}_dropout')(conv)
    if p_spatial_dropout > 0:
        conv = SpatialDropout2D(p_spatial_dropout, name=f'{name_prefix}_spatial_dropout')(conv)
    return conv

def create_unet_network(image_size, nchannels, conv_layers, model_type, kernel_size, padding, p_dropout, p_spatial, lambda_l2, lambda_l1, lrate, n_classes, batch_norm, activation_conv):
    """
    Constructs a U-Net model with flexible configuration for depth, dropout, regularization, and more. Works with shallow 
    (no skip connections) and deep (with skip connections) model types

    :param image_size: Size of the input images (height, width).
    :param nchannels: Number of channels in the input images.
    :param conv_layers: Specifications for each convolutional layer block, including number of filters and pool size.
    :param model_type: Type of U-Net model to construct ('shallow' or 'deep').
    :param kernel_size: Size of the kernel for all Conv2D layers.
    :param padding: Padding strategy for all Conv2D layers. Usually 'same'.
    :param p_dropout: Dropout rate for Dropout layers.
    :param p_spatial: Dropout rate for SpatialDropout2D layers.
    :param lambda_l2: L2 regularization factor. If 0, no L2 regularization is added.
    :param lambda_l1: L1 regularization factor. If 0, no L1 regularization is added.
    :param lrate: Learning rate for the Adam optimizer.
    :param n_classes: Number of classes for the output layer.
    :param batch_norm: If True, adds a BatchNormalization layer to each conv block.
    :param activation_conv: Activation function to use in each conv block.
    """
    regularizer = regularizers.l1_l2(l1=lambda_l1, l2=lambda_l2) if lambda_l2 and lambda_l1 else regularizers.l2(lambda_l2) if lambda_l2 else regularizers.l1(lambda_l1) if lambda_l1 else None

    inputs = Input(shape=(image_size[0], image_size[1], nchannels), name='input_layer')
    x = inputs
    skips = []

  # Downsampling
    for i, layer in enumerate(conv_layers):
        x = create_conv_block(x, layer['filters'],  kernel_size, padding, p_dropout, p_spatial, regularizer, batch_norm, activation_conv, name_prefix=f'conv_down_{i}')
        
        if model_type == 'deep':
            skips.append(x)  # Skip connections are saved only for the deep model
        # Double the number of filters for the conv block right before maxpooling
        x = create_conv_block(x, layer['filters'] * 2, kernel_size, padding, p_dropout, p_spatial, regularizer, batch_norm, activation_conv, name_prefix=f'conv_down_{i}_prepool')

        x = MaxPooling2D((layer['pool_size']), name=f'pool_{i}')(x)
        
    if model_type == 'deep':
        x = create_conv_block(x, conv_layers[-1]['filters'] * 4, kernel_size, padding, p_dropout, p_spatial, regularizer, batch_norm, activation_conv, name_prefix='conv_bottleneck')
    x = create_conv_block(x, conv_layers[-1]['filters'] * 2, kernel_size, padding, p_dropout, p_spatial, regularizer, batch_norm, activation_conv, name_prefix='conv_bottom')
    
   # Upsampling
    for i, layer in enumerate(reversed(conv_layers)):
        x = UpSampling2D(size=( layer['pool_size']), name=f'up_sample_{i}')(x)
        if model_type == 'deep' and skips:
            skip = skips.pop()
            x = Concatenate(name=f'concat_{i}')([x, skip])  # Concatenation for deep model
        x = create_conv_block(x, layer['filters'],  kernel_size, padding, p_dropout, p_spatial, regularizer,batch_norm,activation_conv, name_prefix=f'conv_up_{i}')

    # Output layer
    x = Conv2D(n_classes, (1, 1), padding=padding, activation='softmax', name='output_layer')(x)

    model = Model(inputs=inputs, outputs=x, name=f'UNet_{model_type}')
    model.compile(optimizer=tf.optimizers.Adam(learning_rate=lrate),
              loss=tf.keras.losses.SparseCategoricalCrossentropy(),
              metrics=[tf.keras.metrics.SparseCategoricalAccuracy()])


    return model
