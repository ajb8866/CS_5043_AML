import matplotlib.pyplot as plt
import numpy as np
import os
import pickle
import tensorflow as tf
from tensorflow.keras.models import load_model
from tensorflow.keras.preprocessing import image

DEEP_RESULTS_DIR = '/scratch/ajb8866/deep'
SHALLOW_RESULTS_DIR = '/scratch/ajb8866/shallow'
NPY_SHALLOW_IMAGE_DIR = '/scratch/ajb8866/shallow/image_npy'
NPY_DEEP_IMAGE_DIR = '/scratch/ajb8866/deep/image_npy'



def load_results_from_dir(directory):
    """
    Load all result files from a given directory.

    :param directory: Directory containing result files.
    :return: List of loaded result files.
    """
    results = []
    for filename in os.listdir(directory):
        if filename.endswith('.pkl'):
            with open(os.path.join(directory, filename), 'rb') as file:
                results.append(pickle.load(file))
    return results
   
def load_npy_data(file_path):
    """
    Load image, true labels, and predicted labels from a .npy file.
    """
    with open(file_path, 'rb') as f:
        images = np.load(f)
        true_labels = np.load(f)
        predicted_labels = np.load(f)
    return images, true_labels, predicted_labels

def plot_interesting_row_examples(npy_dir, results_path, num_examples=10):
    """
    Plot interesting examples from .npy files stored in npy_dir.
    Each example is plotted in a row with three columns: Satellite image, True labels, Predicted labels.

    :param npy_dir: Directory containing the .npy files for top and bottom accuracy images.
    :param results_path: Directory where the plots will be saved.
    :param num_examples: Number of interesting examples to plot. Assumes equal number of top and bottom accuracy images.
    """
    # Ensure results_path exists
    os.makedirs(results_path, exist_ok=True)
    
    # Iterate over top and bottom examples
    for prefix in ["top", "bottom"]:
        plt.figure(figsize=(15, 5 * num_examples))
        
        for i in range(num_examples):
            file_path = os.path.join(npy_dir, f"{prefix}_accuracy_image_{i}.npy")
            with open(file_path, 'rb') as f:
                image = np.load(f)
                true_label = np.load(f)
                predicted_label = np.load(f)
            
            # Plot satellite image
            plt.subplot(num_examples, 3, i*3 + 1)
            plt.imshow(image[..., :3])  # Assuming the first 3 channels are RGB
            plt.title("Satellite Image")
            plt.axis('off')
            
            # Plot true labels
            plt.subplot(num_examples, 3, i*3 + 2)
            plt.imshow(true_label, cmap='viridis')
            plt.title("True Labels")
            plt.axis('off')
            
            # Plot predicted labels
            plt.subplot(num_examples, 3, i*3 + 3)
            plt.imshow(predicted_label, cmap='viridis')
            plt.title("Predicted Labels")
            plt.axis('off')
        
        plt.tight_layout()
        plt.savefig(os.path.join(results_path, f"{prefix}_accuracy_examples.png"))
        plt.close()


def extract_metrics(results):
    """
    Extract validation loss and accuracy from results.

    :param results: List of results.
    :return: Lists of validation loss, validation accuracy, and test accuracy.
    """
    val_losses = []
    val_accuracies = []
    test_accuracies = []
    for result in results:
        val_losses.append(result['history']['val_loss'])
        val_accuracies.append(result['history']['val_accuracy'])
        test_accuracies.append(result['predict_testing_eval'][1])
    return val_losses, val_accuracies, test_accuracies

def plot_validation_accuracy(val_accuracies, title_prefix):
    """
    Plot learning curves for validation accuracy.

    :param val_accuracies: List of validation accuracies.
    :param title_prefix: Prefix for the plot title.
    """
    plt.figure(figsize=(7, 5))
    for i, acc in enumerate(val_accuracies):
        epochs = range(1, len(acc) + 1)  # Adjust the epoch range based on actual length of acc array
        plt.plot(epochs, acc, label=f'Rotation {i}')
    plt.title(f'{title_prefix} Validation Accuracy')
    plt.xlabel('Epochs')
    plt.ylabel('Accuracy')
    plt.legend()
    plt.tight_layout()
    plt.savefig(f"{title_prefix}_Validation_Accuracy.png")
    plt.clf()

def plot_validation_loss(val_losses, title_prefix):
    """
    Plot learning curves for validation loss.

    :param val_losses: List of validation losses.
    :param title_prefix: Prefix for the plot title.
    """
    plt.figure(figsize=(7, 5))
    for i, loss in enumerate(val_losses):
        epochs = range(1, len(loss) + 1)
        plt.plot(epochs, loss, label=f'Rotation {i}')
    plt.title(f'{title_prefix} Validation Loss')
    plt.xlabel('Epochs')
    plt.ylabel('Loss')
    plt.legend()
    plt.tight_layout()
    plt.savefig(f"{title_prefix}_Validation_Loss.png")
    plt.clf()


def plot_histogram(test_accuracies_shallow, test_accuracies_deep):
    """
    Generate a histogram of test set accuracy for shallow and deep models.

    :param test_accuracies_shallow: List of test accuracies for shallow models.
    :param test_accuracies_deep: List of test accuracies for deep models.
    """
    plt.hist([test_accuracies_shallow, test_accuracies_deep], label=['Shallow', 'Deep'], alpha=0.5, color=['red', 'darkblue'])
    plt.xlabel('Test Accuracy')
    plt.ylabel('Frequency')
    plt.legend()
    plt.title('Test Set Accuracy Histogram')
    plt.savefig("Test_Accuracy_Histogram.png")
    plt.clf()
    

    
if __name__ == "__main__":
    # Load results
    deep_results = load_results_from_dir(DEEP_RESULTS_DIR)
    shallow_results = load_results_from_dir(SHALLOW_RESULTS_DIR)
    
    # Extract metrics
    deep_val_losses, deep_val_accuracies, deep_test_accuracies = extract_metrics(deep_results)
    shallow_val_losses, shallow_val_accuracies, shallow_test_accuracies = extract_metrics(shallow_results)
    
    # Plot validation accuracy and loss for deep models
    plot_validation_accuracy(deep_val_accuracies, "Deep")
    plot_validation_loss(deep_val_losses, "Deep")

    # Plot validation accuracy and loss for shallow models
    plot_validation_accuracy(shallow_val_accuracies, "Shallow")
    plot_validation_loss(shallow_val_losses, "Shallow")
    
    # Plot histogram
    plot_histogram(shallow_test_accuracies, deep_test_accuracies)

    