'''
Deep Learning: HW0 

Command line version

Andrew H. Fagg (andrewhfagg@gmail.com)
'''
import tensorflow as tf
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from tensorflow import keras
import os
import time
import re
import socket

import argparse
import pickle
import wandb

# Tensorflow 2.x way of doing things
from tensorflow.keras.layers import InputLayer, Dense

from tensorflow.keras.models import Sequential

#################################################################
# Default plotting parameters
FONTSIZE = 18
plt.rcParams['figure.figsize'] = (10, 6)
plt.rcParams['font.size'] = FONTSIZE

#################################################################

def build_model(n_inputs, n_hidden_layers, n_units_per_layer, n_output, activation='relu', lrate=0.001):
    '''
    Construct a neural network with configurable hidden layers and activation functions.
    Uses Adam optimizer with a configurable learning rate and MSE loss function.
    - Adam optimizer with configurable learning rate
    - MSE loss function

    :param n_inputs: Number of input dimensions
    :param n_hidden: Number of units in the hidden layer
    :param n_output: Number of ouptut dimensions
    :param n_units_per_layer (list): List containing the number of units for each hidden layer.
    :param activation: Activation function to be used for hidden and output units
    :param lrate: Learning rate for Adam Optimizer
    '''
    
    model = Sequential()
    model.add(InputLayer(input_shape=(n_inputs,)))
    # Adding hidden layers with the specified number of units and activation
    for i in range(n_hidden_layers):
        # Updated naming scheme for hidden layers 
        model.add(Dense(n_units_per_layer[i], name=f"hidden_layer_{i}", activation=activation))
    model.add(Dense(n_output, name="output_layer", activation='linear'))
        
    # Configuring the optimizer with the given learning rate
    opt = tf.keras.optimizers.Adam(learning_rate=lrate)
    model.compile(optimizer=opt, loss='mse')
    model.summary()
    print(model.summary())
    return model

def args2string(args):
    '''
    Translate the current set of arguments
    
    :param args: Command line arguments    
    '''
    return f"exp_{args.exp}_hidden_" + "_".join(map(str, args.hidden))

########################################################


def execute_exp(args, dataset_path="hw0_dataset.pkl"):
    '''
    Execute a single instance of an experiment.  The details are specified in the args object
    
    :param args: Command line arguments
    :param dataset_path: Path to the dataset file
    '''

    ##############################
    # Run the experiment

    # Load the dataset from the provided path
    with open(dataset_path, "rb") as fp:
        data = pickle.load(fp)
    ins, outs = data['ins'], data['outs']
    
    model = build_model(ins.shape[1], len(args.hidden), args.hidden, outs.shape[1], args.activation, args.lrate)
    
    cbs = []
    
    # Describe arguments
    argstring = args2string(args)
    print("EXPERIMENT: %s"%argstring)
    
    # Initialize callbacks for logging and early stopping
    wandb.init(project="HW0", name="HW0_%id"%(args.exp), notes=argstring, config=vars(args))
    wandb.log({"hostname": socket.gethostname()})
    early_stopping_cb = tf.keras.callbacks.EarlyStopping(monitor='loss', patience=10, restore_best_weights=True)

    cbs=[wandb.keras.WandbMetricsLogger(), early_stopping_cb]
    
    # Execute the model training if 'nogo' flag is not set    
    if not args.nogo:
        print("Training...")
        history = model.fit(x=ins, y=outs, epochs=args.epochs, verbose=args.verbose >= 2, callbacks=cbs)
        print("Done Training")

        # Make predictions and calculate errors
        preds = model.predict(ins)
        errors = np.abs(outs - preds)
        max_error = np.max(errors)
        sum_error = np.sum(errors)
        count_exceeding_threshold = np.sum(errors > 0.1)
        count_below_threshold = np.sum(errors <= 0.1)

        obj = {'preds': preds, 'errors': errors,
               'max_error':max_error, 'sum_error':sum_error,'cont_exceeding_threshold': count_exceeding_threshold,
               'history': history.history, 'count_below_threshold':count_below_threshold}

        # Log errors and save results
        table = wandb.Table(data=errors, columns=['errors'])
        wandb.log({"max_abs_error": max_error, "sum_abs_errors": sum_error, "count_exceeding_0.1": count_exceeding_threshold, 'count_below_equal_0.1':count_below_threshold})
        wandb.log({"histogram of errors": wandb.plot.histogram(table, "errors", title="Histogram of Absolute Errors")})

        # Save results to a file
        results_dir = "results"
        os.makedirs(results_dir, exist_ok=True)
        results_path = os.path.join(results_dir, f"hw0_results_exp_{args.exp}.pkl")
        with open(results_path, "wb") as fp:
            pickle.dump(obj, fp)
            
    wandb.finish()
    

def create_parser():
    '''
    Define and return the argparse command line argument parser.
    '''
    parser = argparse.ArgumentParser(description='HW0 Learner')
    parser.add_argument('--exp', type=int, default=0, help='Experiment number')
    parser.add_argument('--hidden', nargs='+', type=int, default=[5], help='Number of nodes in each hidden layer')
    parser.add_argument('--activation', type=str, default='relu', help='Activation function for hidden layers')
    parser.add_argument('--lrate', type=float, default=0.001, help='Learning rate')
    parser.add_argument('--epochs', type=int, default=100, help='Number of epochs')
    parser.add_argument('--verbose', action='count', default=0, help='Verbosity level')
    parser.add_argument('--gpu', action='store_true', help='Use GPU')
    parser.add_argument('--cpus-per-task', type=int, default=None, help='Number of CPUs for the task')
    parser.add_argument('--nogo', action='store_true', help='Flag to skip execution')
    return parser

def display_learning_curve(fname):
    '''
    Display the learning curve that is stored in fname

    :param fname: Results file to load and display
    '''
    with open(fname, "rb") as fp:
        data = pickle.load(fp) 
    
    history = data['history']
    
    # Display learning curve for the loss
    plt.plot(history['loss'])
    plt.ylabel('MSE')
    plt.xlabel('Epochs')
    plt.title('Learning Curve')
    plt.show()

def display_learning_curve_set(dir, base):
    '''
    Plot the learning curves for a set of results

    :param dir: Directory where the result files are stored
    :param base: Base filename pattern for matching result files
    '''
    file_pattern = r'%s_\d+\.pkl$' % base
    files = [f for f in os.listdir(dir) if re.match(file_pattern, f)]
    files.sort()

    for f in files:
        with open(os.path.join(dir, f), "rb") as fp:
            data = pickle.load(fp) 
            # Extract history for plotting 
            history = data['history'] 
            # Label each curve by the file prefix
            plt.plot(history['loss'], label=f.split('.')[0])  
    
    plt.ylabel('MSE')
    plt.xlabel('Epochs')
    plt.title('Learning Curves for Multiple Runs')
    plt.legend()
    
    # Save the plot
    plt.savefig(os.path.join(dir, 'learning_curve_set.png'))
     # Close the plot to free memory
    plt.close()



def display_histogram_absolute_error(dir, base):
    '''
    Plot the histogram of absolute errors across all runs.
    :param dir: Directory where the result files are stored.
    :param base: Base filename pattern for matching result files.
    '''
    file_pattern = r'%s_\d+\.pkl$' % base
    files = [f for f in os.listdir(dir) if re.match(file_pattern, f)]
    files.sort()

    all_errors = np.empty(0)

    for f in files:
        with open(os.path.join(dir, f), "rb") as fp:
            data = pickle.load(fp)  
            # Extract errors for plotting 
            errors = data['errors'] 
            all_errors = np.append(all_errors, errors.flatten()) 

    print('Total number of errors:', len(all_errors))

    # Adjust histogram bins and range as necessary
    plt.hist(all_errors, bins=50, range=[0, np.max(all_errors)], edgecolor='black', color='skyblue')
    plt.ylabel('Frequency')
    plt.xlabel('Absolute Error')
    plt.title('Histogram of Absolute Errors Across All Runs')
    plt.ylim([0, 50])
    # Save the plot
    plt.savefig(os.path.join(dir, 'absolute_error_histogram.png'))
    # Close the plot to free memory
    plt.close()  

if __name__ == "__main__":
    parser = create_parser()
    args = parser.parse_args()
    
    
    # GPU check
    if args.gpu:
        visible_devices = tf.config.get_visible_devices('GPU')
        if visible_devices:
            for device in visible_devices:
                tf.config.experimental.set_memory_growth(device, True)
            print('Using GPU:', visible_devices)
        else:
            print('GPU requested but not available. Proceeding with CPU.')

    # Set number of threads, if specified
    if args.cpus_per_task is not None:
        tf.config.threading.set_intra_op_parallelism_threads(args.cpus_per_task)
        tf.config.threading.set_inter_op_parallelism_threads(args.cpus_per_task)

    if not args.nogo:
        #execute_exp(args)
        display_histogram_absolute_error('results', 'hw0_results_exp')
        # For a set of files
        display_learning_curve_set('results', 'hw0_results_exp')


