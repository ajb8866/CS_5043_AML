#!/bin/bash
# Andrew H. Fagg


#SBATCH --partition=debug_5min
#SBATCH --ntasks=2
#SBATCH --cpus-per-task=16
#SBATCH --mem=2G
#SBATCH --output=results/hw0_%array_%j_stdout.txt
#SBATCH --error=results/hw0_%array_%j_stderr.txt
#SBATCH --time=00:05:00
#SBATCH --job-name=HW0_test
#SBATCH --mail-user=Averi.J.Bates-1@ou.edu
#SBATCH --mail-type=ALL
#SBATCH --chdir=/home/ajb8866/demo/
#SBATCH --array=0-9



. /home/fagg/tf_setup.sh
conda activate dnn

python hw0.py --epochs 175 --exp  $SLURM_ARRAY_TASK_ID --lrate 0.001256 --hidden 226

