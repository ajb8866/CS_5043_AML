import os
import matplotlib.pyplot as plt
import numpy as np
import pickle
import argparse
import fnmatch

def create_plotting_parser():
    '''
    Initializes an argument parser for the plotting script, defining necessary command-line options.
    '''
    
    # Initialize an argument parser for command-line options
    parser = argparse.ArgumentParser(description='Plotting utility for BMI analysis results')

    # Add arguments for the results directory, plot type, and file pattern
    parser.add_argument('--results_path', type=str, default='./results',
                        help='Directory containing the results files to plot')
    parser.add_argument('--plot_type', type=str, choices=['prediction', 'training_folds'],
                        help='Type of plot to generate: prediction or training_folds')
    parser.add_argument('--file_pattern', type=str, default='*.pkl',
                        help='Pattern to match result files (e.g., "*_results.pkl")')
    return parser

def read_results(dirname, file_pattern):
    '''
    Reads and loads results from files matching a specific pattern within a directory.
    
    :param dirname: The directory path where result files are located.
    :param file_pattern: The pattern used to match files within the directory.
    '''
    # List and sort files matching the given pattern in the specified directory
    files = fnmatch.filter(os.listdir(dirname), file_pattern)
    files.sort()
    results = []
    # Load and append results from each file
    for f in files:
        with open(os.path.join(dirname, f), "rb") as fp:
            results.append(pickle.load(fp))
    return results

def plot_prediction(results, save_path='fig1_time.png'):
    '''
    Generates and saves a plot comparing actual and predicted values based on the first result in the list.
    
    :param results: A list of result objects containing 'time_testing', 'outs_testing', and 'predict_testing' data.
    :param save_path: The path where the plot image will be saved.
    '''
    
    # Create and save a plot of predictions vs. actual results
    plt.figure(figsize=(10, 6))
    result = results[0]

    # Plot actual and predicted values
    plt.plot(result['time_testing'], result['outs_testing'], label='Actual', color='orchid')
    plt.plot(result['time_testing'], result['predict_testing'], label='Predicted', color='orange')
    plt.legend()
    plt.xlabel('Time')
    plt.ylabel('Acceleration')
    plt.savefig(save_path)
    
def compute_fvaf_averages(results):
    '''
    Computes average Fraction of Variance Accounted For (FVAF) scores for each training size across multiple results.
    
    :param results: A list of result objects containing evaluation metrics and fold information.
    '''
    
    # Calculate and return average FVAF scores for different training sizes
    fvaf_data = {
        'training_sizes': [],
        'avg_training_fvafs': [],
        'avg_validation_fvafs': [],
        'avg_testing_fvafs': []
    }
    
    fvaf_scores = {}

    for result in results:
        # Extract FVAF scores and training sizes
        training_size = len(result['folds']['folds_training'])
        training_fvaf = result['predict_training_eval'][1]
        validation_fvaf = result['predict_validation_eval'][1]
        testing_fvaf = result['predict_testing_eval'][1]
        
        # Aggregate FVAF scores by training size
        if training_size not in fvaf_scores:
            fvaf_scores[training_size] = {'training': [], 'validation': [], 'testing': []}
        
        fvaf_scores[training_size]['training'].append(training_fvaf)
        fvaf_scores[training_size]['validation'].append(validation_fvaf)
        fvaf_scores[training_size]['testing'].append(testing_fvaf)

    # Calculate average FVAF scores and sort by training size    
    for size, scores in fvaf_scores.items():
        fvaf_data['training_sizes'].append(size)
        fvaf_data['avg_training_fvafs'].append(np.mean(scores['training']))
        fvaf_data['avg_validation_fvafs'].append(np.mean(scores['validation']))
        fvaf_data['avg_testing_fvafs'].append(np.mean(scores['testing']))

    # Sort the results by training size before returning
    # Get the sorted order of indices based on training sizes
    sorted_indices = np.argsort(fvaf_data['training_sizes'])
    
    # Use the sorted indices to sort all lists in fvaf_data
    for key in fvaf_data:
        fvaf_data[key] = [fvaf_data[key][i] for i in sorted_indices]
    
    return fvaf_data    

def plot_fvaf_averages(fvaf_data, save_path='fig2_fvaf.png'):
    '''
    Generates and saves a plot of average FVAF scores across different numbers of training folds.
    
    :param fvaf_data: A dictionary containing training sizes and their corresponding average FVAF scores.
    :param save_path: The path where the plot image will be saved.
    '''
    # Create and save a plot of FVAF averages across training sizes
    plt.figure(figsize=(10, 6))
    plt.plot(fvaf_data['training_sizes'], fvaf_data['avg_training_fvafs'], label='Training FVAF', marker='o', color='red')
    plt.plot(fvaf_data['training_sizes'], fvaf_data['avg_validation_fvafs'], label='Validation FVAF', marker='D', color = 'skyblue')
    plt.plot(fvaf_data['training_sizes'], fvaf_data['avg_testing_fvafs'], label='Testing FVAF', marker='^', color='seagreen')
    
    plt.xlabel('Number of Training Folds')
    plt.ylabel('Average FVAF')
    plt.title('FVAF as a Function of Training Set Size')
    plt.legend()
    plt.grid(True)
    plt.savefig(save_path)
    
if __name__ == "__main__":
    parser = create_plotting_parser()
    args = parser.parse_args()

    results = read_results(args.results_path, args.file_pattern)

    # Generate the requested plot type based on command-line arguments
    if args.plot_type == 'prediction':
        plot_prediction(results)
    elif args.plot_type == 'training_folds':
        fvaf_data = compute_fvaf_averages(results)
        plot_fvaf_averages(fvaf_data)