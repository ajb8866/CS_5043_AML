import matplotlib.pyplot as plt
import numpy as np
import os
import pickle
import tensorflow as tf
from tensorflow.keras.models import load_model
from tensorflow.keras.preprocessing import image



GRU_RESULTS_DIR = '/home/ajb8866/HW6/results/gru/'
MHA_RESULTS_DIR = '/home/ajb8866/HW6/results/mha'
PLOTS_DIR = '/home/ajb8866/HW6/results/plots'


def load_results_from_dir(directory):
    """
    Load all result files from a given directory.

    :param directory: Directory containing result files.
    :return: List of loaded result files.
    """
    results = []
    for filename in os.listdir(directory):
        if filename.endswith('.pkl'):
            with open(os.path.join(directory, filename), 'rb') as file:
                results.append(pickle.load(file))
    return results
   

def extract_metrics(results):
    """
    Extract validation loss and accuracy from results.

    :param results: List of results.
    :return: Lists of validation loss, validation accuracy, and test accuracy.
    """
    val_losses = []
    val_accuracies = []
    test_accuracies = []
    test_accuracies_final =[]
    for result in results:
        val_losses.append(result['history']['val_loss'])
        val_accuracies.append(result['history']['val_sparse_categorical_accuracy'])
        test_accuracies.append(result['history']['sparse_categorical_accuracy'])
        test_accuracies_final.append(result['predict_testing_eval'][1])
    return val_losses, val_accuracies, test_accuracies, test_accuracies_final

def get_color_shades(base_color, num_shades):
    """
    Generate different shades of a base color.
    
    :param base_color: A matplotlib color string.
    :param num_shades: Number of shades to generate.
    :return: List of color shades.
    """
    base = plt.get_cmap(base_color) 
    return [base(1. * i/num_shades) for i in range(num_shades)]

def plot_combined_test_accuracy(mha_test_accuracies, gru_test_accuracies):
    """
    Plot learning curves for test accuracy for both MHA and GRU models on the same graph.

    :param mha_test_accuracies: List of test accuracies for MHA models.
    :param gru_test_accuracies: List of test accuracies for GRU models.
    """
    plt.figure(figsize=(10, 8))
    mha_colors = get_color_shades('ocean', len(mha_test_accuracies))
    gru_colors = get_color_shades('plasma', len(gru_test_accuracies))
    for i, acc in enumerate(mha_test_accuracies):
        epochs = range(1, len(acc) + 1)
        plt.plot(epochs, acc, label=f'MHA Rotation {i}', linestyle='dotted', color=mha_colors[i])
    for i, acc in enumerate(gru_test_accuracies):
        epochs = range(1, len(acc) + 1)
        plt.plot(epochs, acc, label=f'GRU Rotation {i}', linestyle='--', color=gru_colors[i])
    plt.title(f'Test Accuracy')
    plt.xlabel('Epochs')
    plt.ylabel('Accuracy')
    plt.legend()
    plt.tight_layout()
    plt.savefig(os.path.join(PLOTS_DIR, f"Test_Accuracy.png"))
    plt.clf()
    
def plot_combined_validation_accuracy(mha_val_accuracies, gru_val_accuracies):
    """
    Plot learning curves for validation accuracy for both MHA and GRU models on the same graph.

    :param mha_val_accuracies: List of validation accuracies for MHA models.
    :param gru_val_accuracies: List of validation accuracies for GRU models.
    :param title: Title for the plot.
    """
    plt.figure(figsize=(10, 8))
    mha_colors = get_color_shades('ocean', len(mha_val_accuracies))
    gru_colors = get_color_shades('plasma', len(gru_val_accuracies))
    for i, acc in enumerate(mha_val_accuracies):
        epochs = range(1, len(acc) + 1)
        plt.plot(epochs, acc, label=f'MHA Rotation {i}', linestyle='dotted', color=mha_colors[i])
    for i, acc in enumerate(gru_val_accuracies):
        epochs = range(1, len(acc) + 1)
        plt.plot(epochs, acc, label=f'GRU Rotation {i}', linestyle='--', color=gru_colors[i])
    plt.title('Valdiation Accuracy')
    plt.xlabel('Epochs')
    plt.ylabel('Accuracy')
    plt.legend()
    plt.tight_layout()
    plt.savefig(os.path.join(PLOTS_DIR, f"Validation_Accuracy.png"))
    plt.clf()
   
def plot_validation_loss(val_losses, title_prefix):
    """
    Plot learning curves for validation loss.

    :param val_losses: List of validation losses.
    :param title_prefix: Prefix for the plot title.
    """
    plt.figure(figsize=(10, 8))
    for i, loss in enumerate(val_losses):
        epochs = range(1, len(loss) + 1)
        plt.plot(epochs, loss, label=f'Rotation {i}')
    plt.title(f'{title_prefix} Validation Loss')
    plt.xlabel('Epochs')
    plt.ylabel('Loss')
    plt.legend()
    plt.tight_layout()
    plt.savefig(f"{title_prefix}_Validation_Loss.png")
    plt.clf()
    

def plot_bar_chart(test_accuracies_mha, test_accuracies_gru):
    """
    Generate a bar chart of test set accuracy for mha and gru models, positioning
    the bars next to each other for direct comparison.
    """
    n_groups = 5
    index = np.arange(n_groups)  # Positions for the groups
    bar_width = 0.35  # Width of the bars

    # Plot bars for mha models
    plt.bar(index - bar_width/2, test_accuracies_mha, bar_width,
            alpha=1, color='skyblue', label='mha')

    # Plot bars for gru models, shifted right by bar_width
    plt.bar(index + bar_width/2, test_accuracies_gru, bar_width,
            alpha=1, color='tomato', label='gru')

    # Set the x-axis label, y-axis label, and chart title
    plt.xlabel('Rotation')
    plt.ylabel('Test Accuracy')
    plt.title('Test Accuracy by Model Type and Rotation')

    # Set the position of the ticks and their labels
    plt.xticks(index, ('Rotation 0', 'Rotation 1', 'Rotation 2', 'Rotation 3', 'Rotation 4'))

    # Add a legend to the chart
    plt.legend()

    # Adjust the layout to make room for the tick labels
    plt.tight_layout()

    # Save the figure
    plt.savefig("Test_Accuracy_Bar_Chart.png")
    plt.clf() 
    
    
def plot_epochs_scatter(mha_test_accuracies, gru_test_accuracies):
    """
    Plot a scatter plot of the number of training epochs for the GRU and MHA models.
    
    :param mha_test_accuracies: List of lists containing test accuracies for MHA models across rotations.
    :param gru_test_accuracies: List of lists containing test accuracies for GRU models across rotations.
    """
    # Determine the number of epochs per rotation for each model
    mha_epochs = [len(acc) for acc in mha_test_accuracies]
    gru_epochs = [len(acc) for acc in gru_test_accuracies]

    # Assuming rotations match between models
    rotations = range(len(mha_epochs))

    plt.figure(figsize=(10, 8))

    # Plot MHA epochs
    plt.scatter(rotations, mha_epochs, color='skyblue', label='MHA')

    # Plot GRU epochs
    plt.scatter(rotations, gru_epochs, color='tomato', label='GRU')

    # Add labels, legend, and title
    plt.xlabel('Rotation')
    plt.ylabel('Number of Training Epochs')
    plt.xticks(rotations)  # Ensure we have ticks for each rotation
    plt.title('Number of Training Epochs: GRU vs MHA')
    plt.legend()

    # Save or display the plot
    plt.tight_layout()
    plt.savefig(os.path.join(PLOTS_DIR, "Training_Epochs_GRU_vs_MHA_Scatter.png"))
    plt.clf()


def plot_test_accuracy_scatter(mha_test_accuracies, gru_test_accuracies):
    """
    Plot a scatter plot comparing the test set accuracy of MHA and GRU models.

    :param mha_test_accuracies: List of test accuracies for MHA models.
    :param gru_test_accuracies: List of test accuracies for GRU models.
    """
    # Generate figure and axis
    plt.figure(figsize=(10, 8))
    
    # Plot each pair of MHA and GRU test accuracy
    for i in range(len(mha_test_accuracies)):
        plt.scatter(i, mha_test_accuracies[i], color='skyblue', label='MHA' if i == 0 else "")
        plt.scatter(i, gru_test_accuracies[i], color='tomato', label='GRU' if i == 0 else "")
    
    # Adding labels and title
    plt.xlabel('Rotation')
    plt.ylabel('Test Set Accuracy')
    plt.title('Plot of Test Set Accuracy: GRU vs MHA')
    plt.legend()
    
    # Save the plot
    plt.tight_layout()
    plt.savefig(os.path.join(PLOTS_DIR, "GRU_vs_MHA_Test_Accuracy_Scatter.png"))
    plt.clf()


    
if __name__ == "__main__":
    os.makedirs(PLOTS_DIR, exist_ok=True)

    # Load results
    mha_results = load_results_from_dir(MHA_RESULTS_DIR)
    gru_results = load_results_from_dir(GRU_RESULTS_DIR)
    
    # Extract metrics
    mha_val_losses, mha_val_accuracies, mha_test_accuracies, mha_test_accuracies_final = extract_metrics(mha_results)
    gru_val_losses, gru_val_accuracies, gru_test_accuracies, gru_test_accuracies_final = extract_metrics(gru_results)

    # Plot validation accuracy and loss for mha models
    plot_combined_validation_accuracy(mha_val_accuracies, gru_val_accuracies)
    plot_combined_test_accuracy(mha_test_accuracies, gru_test_accuracies)

    plot_validation_loss(mha_val_losses, "mha")
    
    plot_validation_loss(gru_val_losses, "gru")
    
    plot_bar_chart(mha_test_accuracies_final, gru_test_accuracies_final)
    
    plot_test_accuracy_scatter(mha_test_accuracies_final, gru_test_accuracies_final)

    plot_epochs_scatter(mha_test_accuracies, gru_test_accuracies)


        