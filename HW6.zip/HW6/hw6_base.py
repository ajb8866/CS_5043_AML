'''
Advanced Machine Learning, 2024
HW 6 Base Code

Author: Andrew H. Fagg (andrewhfagg@gmail.com)

Image Segmentation U-Net

Updates for using caching and GPUs
- Batch file:
#SBATCH --gres=gpu:1
#SBATCH --partition=gpu
or
#SBATCH --partition=disc_dual_a100_students
#SBATCH --cpus-per-task=64

- Command line options to include
--cache $LSCRATCH                              (use lscratch to cache the datasets to local fast disk)
--batch 4096                                   (this parameter is per GPU)
--gpu
--precache datasets_by_fold_4_objects          (use a 4-object pre-constructed dataset)

Notes: 
- batch is now a parameter per GPU.  If there are two GPUs, then this number is doubled internally.
   Note that you must do other things to make use of more than one GPU
- 4096 works on the a100 GPUs
- The prcached dataset is a serialized copy of a set of TF.Datasets (located on slow spinning disk).  
Each directory contains all of the images for a single data fold within a couple of files.  Loading 
these files is *a lot* less expensive than having to load the individual images and preprocess them 
at the beginning of a run.
- The cache is used to to store the loaded datasets onto fast, local SSD so they can be fetched quickly
for each training epoch

'''

import sys
import wandb
import os
import argparse
import pickle
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import tensorflow as tf
import socket

from tensorflow.keras.utils import plot_model
from sklearn.metrics import confusion_matrix
import seaborn as sns
import matplotlib.pyplot as plt
from tensorflow.keras.callbacks import ModelCheckpoint


#############
# REMOVE THESE LINES if symbiotic_metrics, job_control, networks are in the same directory
#tf_tools = "../../../../tf_tools/"
#sys.path.append(tf_tools + "metrics")
#sys.path.append(tf_tools + "experiment_control")
#sys.path.append(tf_tools + "networks")
#############

# Provided
from job_control import *
from hw6_parser import *
from pfam_loader import *


# You need to provide this yourself
from gru_mha import *

#################################################################
# Default plotting parameters
FIGURESIZE=(10,6)
FONTSIZE=18

plt.rcParams['figure.figsize'] = FIGURESIZE
plt.rcParams['font.size'] = FONTSIZE

plt.rcParams['xtick.labelsize'] = FONTSIZE
plt.rcParams['ytick.labelsize'] = FONTSIZE

#################################################################

def load_meta_data_set(fname = 'classes.pkl'):
    '''
    Load the metadata for a multi-class data set

    The returned data set is:
    - A python list of classes
    - Each class has a python list of object
    - Each object is described as using a DataFrame that contains file
       locations/names and class labels


    :param fname: Pickle file with the metadata

    :return: Dictionary containing class data
    '''
    obj = None
    with open(fname, "rb") as fp:
        obj = pickle.load(fp)

    assert obj is not None, "Meta-data loading error"
    print("Read %d classes\n"%obj['nclasses'])
    return obj

def exp_type_to_hyperparameters(args):
    '''
    Adjust this function to generate hyperparameters for experiments comparing  vs. mha
    across different data folds for HW6's labeling task.

    :param args: ArgumentParser containing command-line options.
    :return: A dictionary of hyperparameter sets, mapping parameter names to lists of values.
    '''
    # Default experiment setup with range of rotation for training/validation
    if args.exp_type is None:
        p = {'rotation': range(5)}
    else:
        assert False, "Unrecognized exp_type"
    return p

#################################################################
def check_args(args):
    assert (args.rotation >= 0 and args.rotation < args.Nfolds), "Rotation must be between 0 and Nfolds"
    assert (args.Ntraining >= 1 and args.Ntraining <= (args.Nfolds-1)), "Ntraining must be between 1 and Nfolds-2"
    assert (args.dropout is None or (args.dropout > 0.0 and args.dropout < 1)), "Dropout must be between 0 and 1"
    assert (args.lrate > 0.0 and args.lrate < 1), "Lrate must be between 0 and 1"
    assert (args.L1_regularization is None or (args.L1_regularization > 0.0 and args.L1_regularization < 1)), "L1_regularizer must be between 0 and 1"
    assert (args.L2_regularization is None or (args.L2_regularization > 0.0 and args.L2_regularization < 1)), "L2_regularizer must be between 0 and 1"
    assert (args.cpus_per_task is None or args.cpus_per_task > 1), "cpus_per_task must be positive or None"
    assert args.model_type in ['gru', 'mha'], "Model type must be 'gru' or 'mha'"

def augment_args(args):
    '''
    Use the jobiterator to override the specified arguments based on the experiment index.

    Modifies the args

    :param args: arguments from ArgumentParser
    :return: A string representing the selection of parameters to be used in the file name
    '''
    
    # Create parameter sets to execute the experiment on.  This defines the Cartesian product
    #  of experiments that we will be executing
    p = exp_type_to_hyperparameters(args)

    # Check index number
    index = args.exp_index
    if(index is None):
        return ""
    
    # Create the iterator
    ji = JobIterator(p)
    print("Total jobs:", ji.get_njobs())
    
    # Check bounds
    assert (args.exp_index >= 0 and args.exp_index < ji.get_njobs()), "exp_index out of range"

    # Print the parameters specific to this exp_index
    print(ji.get_index(args.exp_index))
    
    # Push the attributes to the args object and return a string that describes these structures
    return ji.set_attributes_by_index(args.exp_index, args)
 
    
#################################################################

def generate_fname(args, params_str):
    '''
    Generate the base file name for output files/directories by incorporating model type.
    
    :param args: from argParse
    :params_str: String generated by the JobIterator
    '''
    # Model type
    model_type_str = f"model_{args.model_type}_"  # Add this line to include model type in the filename

    # Hidden unit configuration
    hidden_str = '_'.join(str(x) for x in args.hidden)
    
    # Conv configuration
    conv_size_str = '_'.join(str(x) for x in args.conv_size)
    conv_filter_str = '_'.join(str(x) for x in args.conv_nfilters)
    pool_str = '_'.join(str(x) for x in args.pool)
    
    # Dropout
    dropout_str = f'drop_{args.dropout:.3f}_' if args.dropout is not None else ''
             
    # L1 regularization
    regularizer_l1_str = f'L1_{args.L1_regularization:.6f}_' if args.L1_regularization is not None else ''
        
    # L2 regularization
    regularizer_l2_str = f'L2_{args.L2_regularization:.6f}_' if args.L2_regularization is not None else ''
    
    # Label
    label_str = f"{args.label}_" if args.label is not None else ''
        
    # Experiment type
    experiment_type_str = f"{args.exp_type}_" if args.exp_type is not None else ''

    # learning rate
    lrate_str = f"LR_{args.lrate:.6f}_"
    
    # Assembling all parts into the filename
    filename = "%s/image_%s%s%sCsize_%s_Cfilters_%s_Pool_%s_hidden_%s_%s%s%s%sntrain_%02d_rot_%02d" % (
        args.results_path,
        experiment_type_str,
        label_str,
        model_type_str,  
        conv_size_str,
        conv_filter_str,
        pool_str,
        hidden_str, 
        dropout_str,
        regularizer_l1_str,
        regularizer_l2_str,
        lrate_str,
        args.Ntraining,
        args.rotation

    )
    
    return filename


##############################################################
def execute_exp(args=None):
    '''
    Perform the training and evaluation for a single model
    
    :param args: Argparse arguments
    '''
    # Check the arguments
    if args is None:
        # Case where no args are given (usually, because we are calling from within Jupyter)
        #  In this situation, we just use the default arguments
        parser = create_parser()
        args = parser.parse_args([])
        
    print(f"Executing experiment index: {args.exp_index}")
    
    
    # Override arguments if we are using exp_index
    args_str = augment_args(args)
    
    # Set number of threads, if it is specified
    if args.cpus_per_task is not None:
        tf.config.threading.set_intra_op_parallelism_threads(args.cpus_per_task)
        tf.config.threading.set_inter_op_parallelism_threads(args.cpus_per_task)
    
    # Load protein sequence data
    dat = load_rotation(args.dataset, args.rotation)
    
    input_length = dat['len_max']
    n_tokens = dat['n_tokens']
    n_classes = dat['n_classes']
    
    ds_train, ds_valid, ds_test = create_tf_datasets(dat, batch=args.batch, prefetch=args.prefetch, shuffle=args.shuffle, repeat=args.repeat, cache=True)
    
    print(f"Training on rotatation {args.rotation} with {n_classes} classes.")
    print(f"Training input and tokens: {input_length} with {n_tokens}")

    
    ####################################################
    # Build the model


    # Network config
    # NOTE: this is very specific to our implementation of create_mha_classifier_network()
    #   List comprehension and zip all in one place (ugly, but effective).
    #   Feel free to organize this differently
    conv_layers = [{'filters': f, 'kernel_size': (s,s), 'pool_size': (p,p), 'strides': (p,p)} if p > 1
                   else {'filters': f, 'kernel_size': (s,s), 'pool_size': None, 'strides': None}
                   for s, f, p, in zip(args.conv_size, args.conv_nfilters, args.pool)]

    print("Conv layers:\n%s", str(conv_layers))
    print("\n")
    # Build network: you must provide your own implementation
    model = create_model(input_length=input_length, 
                     n_tokens=n_tokens,
                     n_classes=n_classes, 
                     model_type=args.model_type, 
                     gru_units=args.gru_units,
                     conv_filters=args.conv_nfilters, 
                     kernel_size=args.kernel_size,
                     stride=args.stride,
                     pool_size=args.pool,
                     activation=args.activation_conv,
                     padding=args.padding, 
                     dropout_rate=args.dropout,
                     l1_reg=args.L1_regularization,
                     l2_reg=args.L2_regularization,
                     lrate=args.lrate,
                     hidden=args.hidden,
                     activation_dense=args.activation_dense,
                     num_heads=args.num_heads,
                     output_dim=args.output_dim)

    # Report model structure if verbosity is turned on
    if args.verbose >= 1:
        print(model.summary())

    print(args)

    # Output file base and pkl file
    fbase = generate_fname(args, args_str)
    fname_out = "%s_results.pkl"%fbase
    
    # Perform the experiment?
    if(args.nogo):
        # No!
        print("NO GO")
        print(fbase)
        return

    # Check if output file already exists
    if os.path.exists(fname_out):
        # Results file does exist: exit
        print("File %s already exists"%fname_out)
        return
     
    
    run = wandb.init(project='HW6', name=f'{args.exp_index}_{args.model_type}_rotation_{args.rotation}', config=vars(args))
    wandb.log({'hostname': socket.gethostname()})
             
    # Callbacks
    early_stopping_cb = keras.callbacks.EarlyStopping(
        patience=args.patience,
        restore_best_weights=True,
        min_delta=args.min_delta
    )

    # Weights and Biases
    wandb_metrics_cb = wandb.keras.WandbMetricsLogger()
    
    # Define the checkpoint callback
    checkpoint_cb = ModelCheckpoint(
        f'./results/models/{args.model_type}_best_model_{args.rotation}_{args.epochs}.keras',              # Path where to save the model
        save_best_only=True,          # Only save a model if `val_loss` has improved
        monitor='val_loss',           # Monitor the validation loss
        mode='min'                    # 'min' means the lowest validation loss is considered the best
    )

    # Learn
    history = model.fit(ds_train,
                        epochs=args.epochs,
                        steps_per_epoch=args.steps_per_epoch,
                        use_multiprocessing=True, 
                        verbose=args.verbose,
                        validation_data=ds_valid,
                        callbacks=[early_stopping_cb, wandb_metrics_cb, checkpoint_cb])

   
    print(f'Steps per epoch: {args.steps_per_epoch}')
    
    
    # Create generator for test set
    if ds_test is not None:
        test_predict = model.predict(ds_test)
        test_eval = model.evaluate(ds_test)
        print('Collecting True Lables....')
        y_true = []
        y_pred = []
        for sequences, labels in ds_test:
            preds = model.predict(sequences)
            preds_labels = np.argmax(preds, axis=-1)  # Convert probabilities to class labels
            y_true.extend(labels.numpy())
            y_pred.extend(preds_labels)
        # Compute the confusion matrix
        cm = confusion_matrix(y_true, y_pred, labels=np.arange(n_classes)) 
        cm_name = f"{args.exp_index}_{args.model_type}_rotation_{args.rotation}_confusion_matrix.png"
        plt.figure(figsize=(30, 20))
        sns.heatmap(cm, annot=True, fmt='g', cmap='YlOrRd', xticklabels=range(n_classes), yticklabels=range(n_classes))
        plt.xlabel('Predicted labels')
        plt.ylabel('True labels')
        plt.show()
        plt.savefig(cm_name)


    val_predict= model.predict(ds_valid)
    val_results = model.evaluate(ds_valid)

    train_predict =  model.predict(ds_train, steps=args.steps_per_epoch)
    train_results = model.evaluate(ds_train, steps=args.steps_per_epoch)

    # Generate results data
    results = {}
    results['args'] = args
    
    results['predict_validation'] = val_predict

    print("Evaluate Validation")
    results['predict_validation_eval'] = val_results
       
    print("Evaluate Testing")
    if ds_test is not None:
        results['predict_testing'] = test_predict
        results['predict_testing_eval'] = test_eval

    
    print("Evaluate Training")
    results['predict_training_eval'] = train_results
    results['predict_training'] = train_predict



    results['history'] = history.history
    
    # Log the validation metrics including loss to wandb
    wandb.log({
        "Validation Loss": val_results[0], 
        "Validation Accuracy": val_results[1], 
    })

    # Create a wandb.Table to visualize validation metrics including loss
    val_table = wandb.Table(columns=["Metric", "Value"])
    val_table.add_data("Validation Loss", val_results[0])
    val_table.add_data("Validation Accuracy", val_results[1])

    # Log the table to wandb
    wandb.log({"Validation Metrics": val_table})

    if ds_test is not None:
        # Log the evaluation metrics including loss to wandb
        wandb.log({
            "Test Loss": test_eval[0], 
            "Test Accuracy": test_eval[1],            
        })

        # Create a wandb.Table to visualize metrics including loss
        table2 = wandb.Table(columns=["Metric", "Value"])
        table2.add_data("Test Loss", test_eval[0])
        table2.add_data("Test Accuracy", test_eval[1])
        # Log the table to wandb
        wandb.log({"Evaluation Metrics": table2})

    # Generate and save the model diagram with dynamic filename
    plot_model(model, to_file=f'{args.exp_index}_{args.model_type}_rotation_{args.rotation}_model_diagram.png', show_shapes=True, show_layer_names=True, rankdir='TB', expand_nested=True, dpi=300)
        
    # Save results
    fbase = generate_fname(args, args_str)
    results['fname_base'] = fbase
    with open("%s_results.pkl"%(fbase), "wb") as fp:
        pickle.dump(results, fp)
    
     # Save model
    if args.save_model:
        print("Saving the model...")
        model.save("%s_model"%(fbase))
        
    wandb.finish()
    print(fbase)
    
    return model


def check_completeness(args):
    '''
    Check the completeness of a Cartesian product run.

    All other args should be the same as if you executed your batch, however, the '--check' flag has been set

    Prints a report of the missing runs, including both the exp_index and the name of the missing results file

    :param args: ArgumentParser

    '''
    
    # Get the corresponding hyperparameters
    p = exp_type_to_hyperparameters(args)

    # Create the iterator
    ji = JobIterator(p)

    print("Total jobs: %d"%ji.get_njobs())

    print("MISSING RUNS:")

    indices = []
    # Iterate over all possible jobs
    for i in range(ji.get_njobs()):
        params_str = ji.set_attributes_by_index(i, args)
        # Compute output file name base
        fbase = generate_fname(args, params_str)
    
        # Output pickle file name
        fname_out = "%s_results.pkl"%(fbase)

        if not os.path.exists(fname_out):
            # Results file does not exist: report it
            print("%3d\t%s"%(i, fname_out))
            indices.append(i)

    # Give the list of indices that can be inserted into the --array line of the batch file
    print("Missing indices (%d): %s"%(len(indices),','.join(str(x) for x in indices)))

    
#################################################################
if __name__ == "__main__":
    # Parse and check incoming arguments
    parser = create_parser()
    args = parser.parse_args()
    check_args(args)
    
    # Turn off GPU?
    if not args.gpu:
        os.environ["CUDA_VISIBLE_DEVICES"] = "-1"
        
    # GPU check
    physical_devices = tf.config.list_physical_devices('GPU') 
    n_physical_devices = len(physical_devices)
    if(n_physical_devices > 0):
        for device in physical_devices:
            try:
                tf.config.experimental.set_memory_growth(device, True)
            except RuntimeError as e:
            # This exception is raised if memory growth is attempted to be set
            # after TensorFlow has already started to allocate memory.
                 print('Error setting memory growth for device %s: %s' % (device, e))

        print('We have %d GPUs\n'%n_physical_devices)
    else:
        print('NO GPU')

    if(args.check):
        # Just check to see if all experiments have been executed
        check_completeness(args)
    else:
        # Execute the experiment
        execute_exp(args)
        
