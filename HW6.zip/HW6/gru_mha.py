import tensorflow as tf
from tensorflow.keras.layers import Input, GRU, Bidirectional, AveragePooling1D, Conv1D, GlobalAveragePooling1D, Dense, Dropout, Embedding
from tensorflow.keras.models import Model
from tensorflow.keras import regularizers

from positional_encoder import PositionalEncoding
import numpy as np

def calculate_reduced_length(input_length, kernel_size, stride, padding='valid'):
    """
        Calculate the reduced length of a sequence after convolution or pooling operation.
        
        :param input_length: The original length of the sequence.
        :param kernel_size: The size of the kernel used in the operation.
        :param stride: The stride size used in the operation.
        :param padding: The type of padding used ('same' or 'valid').
        :return: The reduced length of the sequence as an integer.
    """
    if padding == 'same':
        reduced_length = np.ceil(float(input_length) / float(stride))
    elif padding == 'valid':
        reduced_length = np.ceil((float(input_length) - float(kernel_size) + 1) / float(stride))
    else:
        raise ValueError("Padding type not recognized. Only 'same' and 'valid' are valid padding types.")
    return int(reduced_length)

def create_model(input_length, n_tokens, n_classes, model_type, gru_units, conv_filters, kernel_size, stride, pool_size, padding, activation, dropout_rate, l1_reg, l2_reg, lrate, hidden, activation_dense, num_heads, output_dim):
    """
        Constructs and compiles a TensorFlow model based on the specified type (GRU or MHA).
        
        :param input_length: Length of the input sequences.
        :param n_tokens: Number of unique tokens in the dataset (vocabulary size).
        :param n_classes: Number of classes for classification.
        :param model_type: Type of model to create ('gru' for Recurrent Neural Network, 'mha' for Convolutional Neural Network).
        :param gru_units: List of units for each GRU layer (used when model_type is 'gru').
        :param conv_filters: List of filters for each Convolutional layer (used when model_type is 'mha').
        :param kernel_size: Size of the kernels for convolutional layers (list if varies per layer).
        :param stride: Stride size for the convolutional layers.
        :param pool_size: Size of the pooling windows (list if varies per layer).
        :param activation: Activation function for the convolutional layers.
        :param padding: Padding strategy for convolutional layers.
        :param dropout_rate: Dropout rate for regularization.
        :param l1_reg: L2 regularization factor. If 0, no L2 regularization is added.
        :param l2_reg:  L1 regularization factor. If 0, no L1 regularization is added.
        :param lrate: Learning rate for the optimizer.
        :param hidden: List of units for each Dense layer in the model.
        :param activation_dense: Activation function for the Dense layers.
        :param num_heads: Number of attention heads in multi-head attention layers.
        :param output_dim: Dimensionality of the embedding layer output.
    """
    # Input layer specification
    inputs = Input(shape=(input_length,), name='input_layer')
    x = Embedding(input_dim=n_tokens, output_dim=output_dim, input_length=input_length)(inputs)
    regularizer = regularizers.l1_l2(l1=l1_reg, l2=l2_reg) if l1_reg or l2_reg else None

    # Conv1D layer
    x = Conv1D(filters=conv_filters[0], kernel_size=kernel_size, strides=stride, activation=activation, padding=padding)(x)
    # Calculate the reduced length after Conv1D
    conv_reduced_length = calculate_reduced_length(input_length, kernel_size, stride, padding)

    # Construct GRU model layers if model type is GRU
    if model_type == 'gru':
        for i, units in enumerate(gru_units):
            # Determine if the GRU layer should return sequences based on its position
            return_sequences = i < len(gru_units) - 1  
            gru_layer = GRU(units, 
                            return_sequences=return_sequences,
                            kernel_regularizer=regularizer,
                            unroll=True)
            
            # Connect the GRU layer directly without bidirectional wrapper
            x = gru_layer(x)  # Use the GRU layer directly
            
            if return_sequences and pool_size:
                current_pool_size = pool_size[i] if isinstance(pool_size, list) else pool_size
                x = AveragePooling1D(pool_size=current_pool_size, name=f'average_pooling_{i+1}')(x)
    
    # Construct CNN model layers if model type is MHA        
    elif model_type == 'mha':
        # Positional Encoding layer initialization with dynamic sequence length
        x = PositionalEncoding(max_steps=conv_reduced_length, max_dims=output_dim)(x)
        for units in hidden:
            x = tf.keras.layers.MultiHeadAttention(num_heads=num_heads, key_dim=units)(x, x)
       
        # Global pooling to reduce the features to a single vector per feature map
        x = GlobalAveragePooling1D(name='global_average_pooling')(x)

    # Dense layers for further learning with dropout for regularization
    for i, units in enumerate(hidden):
        x = Dense(units, activation=activation_dense, kernel_regularizer=regularizer, name=f'dense_{i+1}')(x)
        if dropout_rate:
            x = Dropout(dropout_rate, name=f'dropout_{i+1}')(x)

    outputs = Dense(n_classes, activation='softmax', name='output')(x)
    model = Model(inputs=inputs, outputs=outputs, name=f"{model_type.upper()}_Model")
    
    # Assemble and compile the model with appropriate optimizer and loss function
    model.compile(optimizer=tf.optimizers.Adam(learning_rate=lrate),
                      loss=tf.keras.losses.SparseCategoricalCrossentropy(),
                      metrics=[tf.keras.metrics.SparseCategoricalAccuracy()])
    return model